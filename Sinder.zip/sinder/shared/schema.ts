import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const bots = pgTable("bots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().default("Sinder"),
  token: text("token").notNull(),
  status: text("status").notNull().default("offline"), // online, offline, error
  personality: jsonb("personality").notNull().default({
    neediness: 95,
    playfulness: 88,
    intelligence: 92,
    bratiness: 75,
    dumbness: 50,
    horniness: 200,
    description: "A catgirl succubus who is extremely needy and emotionally dependent"
  }),
  memory: jsonb("memory").notNull().default({
    conversations: [],
    emotions: [],
    preferences: []
  }),
  settings: jsonb("settings").notNull().default({
    groqApiKey: "",
    huggingFaceKey: "",
    randomMessaging: true,
    nsfwEnabled: true
  }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

export const servers = pgTable("servers", {
  id: varchar("id").primaryKey(),
  botId: varchar("bot_id").references(() => bots.id),
  name: text("name").notNull(),
  memberCount: integer("member_count").default(0),
  active: boolean("active").default(true),
  inviteUrl: text("invite_url"),
  createdAt: timestamp("created_at").defaultNow()
});

export const commands = pgTable("commands", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  botId: varchar("bot_id").references(() => bots.id),
  name: text("name").notNull(),
  description: text("description").notNull(),
  response: text("response").notNull(),
  category: text("category").notNull().default("general"), // general, nsfw, emotion
  enabled: boolean("enabled").default(true),
  aiGenerated: boolean("ai_generated").default(false),
  createdAt: timestamp("created_at").defaultNow()
});

export const memories = pgTable("memories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  botId: varchar("bot_id").references(() => bots.id),
  type: text("type").notNull(), // conversation, emotion, preference, event
  content: text("content").notNull(),
  context: jsonb("context").notNull().default({}),
  importance: integer("importance").default(5), // 1-10 scale
  createdAt: timestamp("created_at").defaultNow()
});

export const images = pgTable("images", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  botId: varchar("bot_id").references(() => bots.id),
  prompt: text("prompt").notNull(),
  url: text("url").notNull(),
  category: text("category").notNull().default("general"), // general, nsfw
  createdAt: timestamp("created_at").defaultNow()
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  discordId: varchar("discord_id").notNull().unique(),
  username: text("username").notNull(),
  displayName: text("display_name"),
  isOwner: boolean("is_owner").default(false),
  relationship: text("relationship").default("stranger"), // owner, friend, stranger
  trustLevel: integer("trust_level").default(0), // 0-10 scale
  interactionCount: integer("interaction_count").default(0),
  firstSeen: timestamp("first_seen").defaultNow(),
  lastSeen: timestamp("last_seen").defaultNow(),
  personality: jsonb("personality").default({}), // How bot perceives this user
  notes: text("notes") // Bot's private notes about this user
});

export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  botId: varchar("bot_id").references(() => bots.id),
  userId: varchar("user_id").references(() => users.id),
  serverId: varchar("server_id"),
  channelId: varchar("channel_id"),
  message: text("message").notNull(),
  response: text("response"),
  context: jsonb("context").default({}),
  emotion: text("emotion"), // Bot's emotional state during conversation
  importance: integer("importance").default(5), // 1-10 scale for memory prioritization
  createdAt: timestamp("created_at").defaultNow()
});

export const userRelationships = pgTable("user_relationships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  botId: varchar("bot_id").references(() => bots.id),
  userId: varchar("user_id").references(() => users.id),
  relationshipType: text("relationship_type").notNull(), // owner, friend, acquaintance, stranger
  closenessLevel: integer("closeness_level").default(0), // 0-100 scale
  trustLevel: integer("trust_level").default(0), // 0-100 scale
  notes: text("notes"),
  lastInteraction: timestamp("last_interaction").defaultNow(),
  createdAt: timestamp("created_at").defaultNow()
});

export const insertBotSchema = createInsertSchema(bots).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertServerSchema = createInsertSchema(servers).omit({
  createdAt: true
});

export const insertCommandSchema = createInsertSchema(commands).omit({
  id: true,
  createdAt: true
});

export const insertMemorySchema = createInsertSchema(memories).omit({
  id: true,
  createdAt: true
});

export const insertImageSchema = createInsertSchema(images).omit({
  id: true,
  createdAt: true
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  firstSeen: true,
  lastSeen: true
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true
});

export const insertUserRelationshipSchema = createInsertSchema(userRelationships).omit({
  id: true,
  createdAt: true,
  lastInteraction: true
});

export const personalitySchema = z.object({
  neediness: z.number().min(0).max(100).default(50),
  playfulness: z.number().min(0).max(100).default(50),
  intelligence: z.number().min(0).max(100).default(50),
  bratiness: z.number().min(0).max(100).default(50),
  dumbness: z.number().min(0).max(100).default(50),
  horniness: z.number().min(0).max(100).default(50),
  description: z.string().optional(),
  brainwashPrompt: z.string().optional(),
  randomPingsEnabled: z.boolean().default(false),
  pingIntervalMin: z.number().min(5).max(120).default(15),
  pingIntervalMax: z.number().min(5).max(120).default(45),
});

export type Bot = typeof bots.$inferSelect;
export type InsertBot = z.infer<typeof insertBotSchema>;
export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;
export type Command = typeof commands.$inferSelect;
export type InsertCommand = z.infer<typeof insertCommandSchema>;
export type Memory = typeof memories.$inferSelect;
export type InsertMemory = z.infer<typeof insertMemorySchema>;
export type Image = typeof images.$inferSelect;
export type InsertImage = z.infer<typeof insertImageSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type UserRelationship = typeof userRelationships.$inferSelect;
export type InsertUserRelationship = z.infer<typeof insertUserRelationshipSchema>;
