#!/usr/bin/env node
/**
 * Export script for Railway deployment
 * Run: node export-for-railway.js
 */

import fs from 'fs';
import path from 'path';

console.log('🚂 Preparing project for Railway deployment...\n');

// Files to exclude from Railway deployment
const excludeFiles = [
  '.replit',
  '.upm',
  'replit.nix',
  'export-for-railway.js',
  '.git',
  'node_modules',
  '.env',
  'keep_alive.py',
  '__pycache__',
  '*.pyc'
];

// Check if essential files exist
const essentialFiles = [
  'package.json',
  'server/index.ts',
  'client/src/App.tsx',
  'shared/schema.ts',
  'drizzle.config.ts'
];

console.log('✅ Checking essential files...');
essentialFiles.forEach(file => {
  if (fs.existsSync(file)) {
    console.log(`   ✓ ${file}`);
  } else {
    console.log(`   ❌ ${file} - MISSING!`);
  }
});

// Check package.json scripts
console.log('\n📦 Checking package.json scripts...');
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));

const requiredScripts = {
  'build': 'Build script for production',
  'start': 'Start script for Railway',
  'dev': 'Development script',
  'db:push': 'Database migration script'
};

Object.entries(requiredScripts).forEach(([script, description]) => {
  if (packageJson.scripts && packageJson.scripts[script]) {
    console.log(`   ✓ ${script}: ${packageJson.scripts[script]}`);
  } else {
    console.log(`   ❌ ${script} - MISSING! (${description})`);
  }
});

// Check environment variables needed
console.log('\n🔑 Environment variables needed for Railway:');
const requiredEnvVars = [
  'DISCORD_BOT_TOKEN',
  'GROQ_API_KEY', 
  'HUGGINGFACE_API_KEY',
  'DATABASE_URL',
  'NODE_ENV'
];

requiredEnvVars.forEach(envVar => {
  console.log(`   • ${envVar}`);
});

// Create .env.example for Railway
console.log('\n📝 Creating .env.example for Railway...');
const envExample = `# Discord Bot Configuration
DISCORD_BOT_TOKEN=your_discord_bot_token_here
GROQ_API_KEY=your_groq_api_key_here
HUGGINGFACE_API_KEY=your_huggingface_token_here

# Database (Railway will auto-provide this)
DATABASE_URL=postgresql://user:pass@host:port/db

# Environment
NODE_ENV=production
`;

fs.writeFileSync('.env.example', envExample);
console.log('   ✓ .env.example created');

// Create Railway-specific files
console.log('\n🛠️ Creating Railway configuration...');

// Procfile for Railway (optional, but helpful)
const procfile = `web: npm start
`;
fs.writeFileSync('Procfile', procfile);
console.log('   ✓ Procfile created');

// Railway-specific package.json modifications check
console.log('\n⚙️ Verifying Railway compatibility...');

if (packageJson.engines) {
  console.log(`   ✓ Node.js version specified: ${packageJson.engines.node || 'not specified'}`);
} else {
  console.log('   ⚠️ Consider adding engines field to package.json');
}

// Create deployment checklist
console.log('\n📋 Creating deployment checklist...');
const checklist = `# Railway Deployment Checklist

## Before Deployment
- [ ] All files exported from Replit
- [ ] .replit file removed (not needed for Railway)
- [ ] Environment variables ready

## API Keys Required
- [ ] Discord Bot Token from Discord Developer Portal
- [ ] Groq API Key from console.groq.com (Free)
- [ ] HuggingFace Token from huggingface.co/settings (Free)

## Railway Setup
- [ ] Project deployed to Railway
- [ ] PostgreSQL database added
- [ ] Environment variables configured
- [ ] Build successful
- [ ] Bot appears online in Discord

## Testing
- [ ] /help command works
- [ ] /draw generates images
- [ ] AI conversations respond
- [ ] Dashboard accessible
- [ ] All permissions working

## Bot Permissions
Your bot now has comprehensive Discord permissions:
- ✅ All text permissions (send, manage, embed, attach)
- ✅ Voice permissions (connect, speak, move members)  
- ✅ Server management (roles, channels, webhooks)
- ❌ Administrator (excluded for security)

Invite URL: Get from dashboard → Servers → Invite URL
`;

fs.writeFileSync('RAILWAY_CHECKLIST.md', checklist);
console.log('   ✓ RAILWAY_CHECKLIST.md created');

console.log('\n🎉 Railway deployment preparation complete!');
console.log('\n📤 Next steps:');
console.log('1. Download this project as ZIP from Replit (hamburger menu → Export → Download ZIP)');
console.log('2. Extract ZIP and remove .replit file');
console.log('3. Upload to Railway or push to GitHub');
console.log('4. Add environment variables in Railway dashboard');
console.log('5. Deploy and test!');
console.log('\nSee RAILWAY_DEPLOYMENT_GUIDE.md for detailed instructions.');