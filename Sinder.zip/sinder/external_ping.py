#!/usr/bin/env python3
"""
External Ping Service - Prevents Replit from sleeping
Continuously pings external services every 2 minutes
"""

import requests
import time
import threading
from datetime import datetime

def external_ping_service():
    """Ping external services to maintain activity"""
    
    external_endpoints = [
        "https://httpbin.org/get",
        "https://api.github.com",
        "https://jsonplaceholder.typicode.com/posts/1",
        "https://discord.com/api/v10/gateway",
        "https://api.pollinations.ai/models",
        "https://httpstat.us/200"
    ]
    
    ping_interval = 2 * 60  # 2 minutes
    
    print("🌐 Starting external ping service...")
    
    while True:
        try:
            timestamp = datetime.now().strftime("%H:%M:%S")
            
            for endpoint in external_endpoints:
                try:
                    response = requests.get(endpoint, timeout=10)
                    if response.status_code in [200, 401, 429, 403]:  # Accept various success/auth codes
                        print(f"✅ [{timestamp}] External ping successful: {endpoint}")
                        break
                except Exception as e:
                    print(f"⚠️ [{timestamp}] External ping failed {endpoint}: {e}")
                    continue
            
            # Keep CPU active briefly
            import hashlib
            test_data = f"external_ping_{time.time()}".encode()
            hashlib.sha256(test_data).hexdigest()
            
        except Exception as e:
            print(f"💥 External ping service error: {e}")
        
        time.sleep(ping_interval)

if __name__ == "__main__":
    external_ping_service()