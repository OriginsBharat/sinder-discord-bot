# Discord AI Bot Dashboard

## Overview

This is a comprehensive Discord bot management dashboard built with a React frontend and Express backend. The application focuses on creating and managing AI-powered Discord bots with customizable personalities, commands, and memory systems. The primary bot "Sinder" is designed as a catgirl character with emotional AI capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured error handling
- **Middleware**: Custom logging middleware for API requests
- **Development**: Hot reloading with Vite integration in development mode

### Database Architecture
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon database)
- **Schema**: Centralized schema definitions in shared directory
- **Migrations**: Drizzle Kit for database migrations

## Key Components

### Bot Management System
- **Bot Configuration**: Store bot tokens, names, and operational status
- **Personality System**: Configurable personality traits (neediness, playfulness, intelligence, bratiness)
- **Memory Management**: Conversation history and emotional state tracking
- **Command System**: Custom commands with AI-generated responses

### AI Integration Services
- **Groq API**: Primary AI service for generating responses using Mixtral model
- **Hugging Face**: Image generation capabilities
- **Context-Aware Responses**: AI responses consider bot personality and conversation history

### Discord Integration
- **Discord.js**: Full Discord bot functionality with intent-based permissions
- **Multi-Server Support**: Manage bot across multiple Discord servers
- **Real-time Status**: Live bot status monitoring and control

### User Interface Components
- **Dashboard**: Overview of bot status, memory, and server statistics
- **Personality Editor**: Visual sliders and text areas for personality customization
- **Command Builder**: Interface for creating and managing custom commands
- **Memory Bank**: View and manage bot conversation memories
- **Image Gallery**: AI-generated image management
- **Server Manager**: Discord server management and bot invitation

## Data Flow

1. **Client Requests**: React frontend makes API calls using TanStack Query
2. **API Processing**: Express backend processes requests with middleware logging
3. **Database Operations**: Drizzle ORM handles all database interactions
4. **Discord Integration**: Bot actions are executed through Discord.js client
5. **AI Processing**: External API calls to Groq/Hugging Face for AI capabilities
6. **Real-time Updates**: Status polling and query invalidation for live updates

## External Dependencies

### Required API Keys
- **Discord Bot Token**: For Discord API access and bot functionality
- **Groq API Key**: For AI text generation and conversation responses
- **Hugging Face API Key**: For AI image generation capabilities

### Core Libraries
- **Discord.js**: Discord API wrapper with comprehensive bot features
- **Groq SDK**: Official SDK for Groq AI API integration
- **TanStack Query**: Powerful data synchronization for React
- **Radix UI**: Unstyled, accessible UI component primitives
- **Drizzle ORM**: Type-safe SQL ORM with excellent TypeScript support

### Development Tools
- **TypeScript**: Full type safety across frontend and backend
- **Vite**: Fast build tool with HMR and optimized production builds
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **ESBuild**: Fast JavaScript bundler for production builds

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to `dist/public` directory
- **Backend**: ESBuild bundles Express server to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **GROQ_API_KEY**: Optional default Groq API key
- **NODE_ENV**: Environment mode (development/production)

### Production Setup
1. Install dependencies with `npm install`
2. Build both frontend and backend with `npm run build`
3. Set required environment variables
4. Run database migrations with `npm run db:push`
5. Start production server with `npm start`

### Development Workflow
- **Development Server**: `npm run dev` starts Express with Vite middleware
- **Type Checking**: `npm run check` validates TypeScript across all packages
- **Hot Reloading**: Automatic reload for both client and server code changes

## Advanced 24/7 Bot System

### Overview
Implemented a comprehensive always-on Discord bot architecture with no manual on/off controls, featuring advanced monitoring, automatic restart capabilities, and continuous uptime tracking.

### Key Features
- **24/7 Operation Mode**: Bot runs continuously without manual intervention
- **Advanced Keep-Alive System**: Flask monitoring server on port 8080 with comprehensive health dashboard
- **Automatic Recovery**: 5-minute ping intervals with automatic bot restart on connection loss
- **Comprehensive Monitoring**: Real-time system statistics, uptime tracking, and error logging
- **Multiple Health Endpoints**: /ping, /health, /api/system/status for external monitoring
- **Self-Ping Mechanism**: Multi-endpoint ping system to prevent sleeping/hibernation

### Architecture Components

#### 24/7 Bot Manager (`server/start-24-7.ts`)
- Singleton pattern for bot lifecycle management
- Auto-initialization with error handling and graceful shutdown
- Process monitors for uncaught exceptions and signals
- Comprehensive system status reporting with formatted uptime

#### Enhanced Discord Service (`server/services/discord.ts`)
- Uptime monitoring with 5-minute heartbeat intervals
- Automatic restart mechanism on connection loss
- Real-time bot activity updates showing uptime
- Memory logging for system events and restarts
- Advanced statistics tracking (servers, uptime, status)

#### Advanced Keep-Alive System (`keep_alive.py`)
- Flask web server with real-time monitoring dashboard
- Multi-endpoint self-ping mechanism (localhost:8080, localhost:5000)
- System resource monitoring (CPU, memory, platform info)
- Comprehensive error logging and recovery
- Advanced HTML dashboard with live statistics

### API Endpoints

#### System Monitoring
- `GET /api/system/status` - Complete system status including bot and server metrics
- `GET /api/system/uptime` - Detailed uptime information for system and bot
- `GET /api/bots/:botId/stats` - Comprehensive bot statistics and health data
- `GET /ping` - Keep-alive endpoint for external monitoring services
- `GET /health` - Health check with detailed status codes (200/503)

#### Keep-Alive Monitoring (Port 8080)
- `GET /` - Advanced monitoring dashboard with real-time updates
- `GET /health` - Python keep-alive health status
- `GET /ping` - Self-ping endpoint with counter
- `GET /api/stats` - Detailed system metrics API

### Implementation Details

#### No Manual Controls
- 24/7 mode is enabled by default in Discord service
- No user-accessible on/off buttons in the interface
- Automatic startup on server initialization
- Continuous operation designed to run indefinitely

#### Monitoring and Recovery
- 5-minute ping intervals to prevent hibernation
- Automatic bot restart on Discord connection loss
- Process-level error handling to maintain operation
- Comprehensive logging for debugging and monitoring

#### External Integration
- Ready for UptimeRobot or similar monitoring services
- Multiple ping endpoints for redundancy
- Health check endpoints return proper HTTP status codes
- Detailed system metrics for monitoring dashboards

### Recent Changes (July 31, 2025)
- ✅ **MAJOR FIX**: Resolved MemStorage class error - backend now starts properly
- ✅ **DATABASE**: Fixed all TypeScript errors in storage implementation  
- ✅ **MULTI-PROVIDER IMAGE GEN**: Implemented 4 free unlimited uncensored APIs
- ✅ **UNLIMITED IMAGES**: Pollinations AI (primary), ImgnAI, Stable Horde, HuggingFace SD 1.5
- ✅ **24/7 MODE**: Enhanced auto-start functionality with retry mechanisms
- ✅ **DEPLOY READY**: Created comprehensive Android-friendly deployment guide
- ✅ **BOT COMMANDS**: All commands working (/draw, /cuddle, /kiss, /headpat, /help)
- ✅ **ONLINE/OFFLINE CONTROL**: Dashboard toggle buttons with real-time status updates
- ✅ **DISCORD INVITE**: Fixed authorization URL with proper permissions and scope
- ✅ **API KEYS CONFIGURED**: All three APIs (Discord, Groq, HuggingFace) working
- ✅ **MONITORING**: 5-minute heartbeat with uptime display in bot status
- 🔧 **DEBUGGING IMAGE ISSUE**: Working on fixing black image display in Discord /draw command

### System Updates (July 30, 2025 - Evening)
- **AI Model Upgrade**: Updated from Mixtral to Llama 3.3-70b-versatile for improved performance
- **Personality Enhancement**: Added 2 new personality traits (dumbness: 50%, horniness: 200%)
- **Image Generation**: Upgraded to Stable Diffusion XL with uncensored model support
- **New Commands**: Added /draw command for AI image generation using HuggingFace
- **Closeness System**: Implemented 4 new closeness commands (/cuddle, /kiss, /headpat, /praise)
- **24/7 Operation**: Removed manual start/stop controls, bot runs continuously
- **API Testing**: Added comprehensive test endpoints for Groq and HuggingFace APIs
- **Memory Enhancement**: Improved emotional memory tracking for user interactions
- **Frontend Updates**: Enhanced personality editor with new sliders and 24/7 status display

### Advanced Character Customization (July 30, 2025 - Late Evening)
- **Brainwash Section**: Added character prompt customization panel for core personality definition
- **Default Character**: Set Sinder as bratty catgirl succubus slave with tragic backstory
- **Random Seductive Pings**: Implemented 15-45 minute interval system for attention-seeking messages
- **AI Integration**: Brainwash prompts now override default personality in all AI responses
- **Frontend Enhancement**: Added dedicated brainwash editor and ping interval controls
- **Memory Tracking**: Random pings logged as events with scheduling information