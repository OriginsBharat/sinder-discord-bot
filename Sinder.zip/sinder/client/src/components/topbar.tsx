import { Menu, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TopBar() {
  return (
    <header className="bg-slate-800/50 backdrop-blur-lg border-b border-purple-500/30 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" className="lg:hidden text-pink-400 hover:text-purple-400">
            <Menu />
          </Button>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
            Sinder Bot Dashboard
          </h1>
        </div>
        <div className="flex items-center space-x-4">
          <div className="bg-purple-500/20 px-3 py-1 rounded-full border border-purple-500/40">
            <span className="text-sm text-purple-300">Premium Active</span>
          </div>
          <Button variant="ghost" size="sm" className="text-pink-400 hover:text-purple-400">
            <Bell />
          </Button>
        </div>
      </div>
    </header>
  );
}
