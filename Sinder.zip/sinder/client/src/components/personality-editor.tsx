import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Wand2, Save, RotateCcw } from "lucide-react";

interface PersonalityEditorProps {
  personality: {
    neediness: number;
    playfulness: number;
    intelligence: number;
    bratiness: number;
    description: string;
  };
  onPersonalityChange: (personality: any) => void;
  onSave: () => void;
  onGenerateWithAI: (description: string) => void;
  isLoading?: boolean;
}

export default function PersonalityEditor({ 
  personality, 
  onPersonalityChange, 
  onSave, 
  onGenerateWithAI,
  isLoading 
}: PersonalityEditorProps) {
  const [aiDescription, setAiDescription] = useState("");

  const handleTraitChange = (trait: string, value: number) => {
    onPersonalityChange({
      ...personality,
      [trait]: value
    });
  };

  const handleDescriptionChange = (description: string) => {
    onPersonalityChange({
      ...personality,
      description
    });
  };

  const resetToDefaults = () => {
    onPersonalityChange({
      neediness: 95,
      playfulness: 88,
      intelligence: 92,
      bratiness: 75,
      description: "A catgirl succubus who is extremely needy and emotionally dependent"
    });
  };

  const getTraitColor = (trait: string) => {
    switch (trait) {
      case "neediness": return "text-pink-400";
      case "playfulness": return "text-purple-400";
      case "intelligence": return "text-yellow-400";
      case "bratiness": return "text-red-400";
      default: return "text-gray-400";
    }
  };

  const getTraitDescription = (trait: string) => {
    switch (trait) {
      case "neediness": return "How clingy and dependent she is";
      case "playfulness": return "How playful and energetic she is";
      case "intelligence": return "How smart she acts normally";
      case "bratiness": return "How bratty and mischievous she is";
      default: return "";
    }
  };

  return (
    <div className="space-y-6">
      
      {/* AI Personality Generator */}
      <Card className="glass-card bg-green-500/10 border-green-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-green-400 font-bold flex items-center">
            <Wand2 className="mr-2" />
            AI Personality Generator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-gray-300 mb-2 block">
              Describe the personality you want:
            </Label>
            <Textarea
              value={aiDescription}
              onChange={(e) => setAiDescription(e.target.value)}
              className="form-field resize-none"
              rows={3}
              placeholder="e.g., 'Make her more clingy and jealous, but also playful and mischievous'"
            />
          </div>
          
          <Button 
            onClick={() => onGenerateWithAI(aiDescription)}
            disabled={!aiDescription.trim() || isLoading}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-500"
          >
            <Wand2 className="mr-2 h-4 w-4" />
            Generate with AI
          </Button>
        </CardContent>
      </Card>

      {/* Manual Editor */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-pink-400 font-bold">
              Manual Personality Editor
            </CardTitle>
            <div className="flex space-x-2">
              <Button
                onClick={resetToDefaults}
                variant="outline"
                size="sm"
                className="btn-ghost"
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button
                onClick={onSave}
                disabled={isLoading}
                className="bg-gradient-to-r from-pink-500 to-purple-500"
              >
                <Save className="mr-2 h-4 w-4" />
                Save
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Description */}
          <div>
            <Label className="text-gray-300 mb-2 block">
              Personality Description
            </Label>
            <Textarea
              value={personality.description}
              onChange={(e) => handleDescriptionChange(e.target.value)}
              className="form-field resize-none"
              rows={3}
              placeholder="Describe Sinder's overall personality..."
            />
          </div>

          {/* Trait Sliders */}
          <div className="space-y-6">
            {Object.entries(personality).map(([trait, value]) => {
              if (trait === 'description') return null;
              
              return (
                <div key={trait}>
                  <div className="flex items-center justify-between mb-3">
                    <Label className={`font-medium capitalize ${getTraitColor(trait)}`}>
                      {trait}: {value}%
                    </Label>
                    <Badge variant="outline" className="text-xs">
                      {value >= 80 ? "Very High" : value >= 60 ? "High" : value >= 40 ? "Medium" : value >= 20 ? "Low" : "Very Low"}
                    </Badge>
                  </div>
                  <Slider
                    value={[value as number]}
                    onValueChange={([newValue]) => handleTraitChange(trait, newValue)}
                    max={100}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">
                    {getTraitDescription(trait)}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Personality Preview */}
          <div className="bg-slate-800/50 rounded-xl p-4 border border-purple-500/30">
            <h4 className="text-sm font-medium text-gray-300 mb-3">Personality Summary:</h4>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="flex justify-between">
                <span className="text-pink-400">Neediness:</span>
                <span className="text-white font-medium">{personality.neediness}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-400">Playfulness:</span>
                <span className="text-white font-medium">{personality.playfulness}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-yellow-400">Intelligence:</span>
                <span className="text-white font-medium">{personality.intelligence}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-red-400">Bratiness:</span>
                <span className="text-white font-medium">{personality.bratiness}%</span>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-600">
              <p className="text-xs text-gray-300">{personality.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
