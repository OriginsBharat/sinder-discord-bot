import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Save, Wand2, Loader2, Bot } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CommandBuilderProps {
  onClose: () => void;
  editingCommand?: any;
}

export default function CommandBuilder({ onClose, editingCommand }: CommandBuilderProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [command, setCommand] = useState({
    name: "",
    description: "",
    response: "",
    category: "general",
    enabled: true,
  });

  const [aiDescription, setAiDescription] = useState("");

  useEffect(() => {
    if (editingCommand) {
      setCommand({
        name: editingCommand.name,
        description: editingCommand.description,
        response: editingCommand.response,
        category: editingCommand.category,
        enabled: editingCommand.enabled,
      });
    }
  }, [editingCommand]);

  const saveCommandMutation = useMutation({
    mutationFn: async (commandData: any) => {
      if (editingCommand) {
        return apiRequest("PATCH", `/api/commands/${editingCommand.id}`, commandData);
      } else {
        return apiRequest("POST", "/api/bots/default-bot/commands", {
          ...commandData,
          aiGenerated: false,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/commands"] });
      toast({
        title: editingCommand ? "Command Updated" : "Command Created",
        description: `Command /${command.name} has been ${editingCommand ? "updated" : "created"} successfully!`,
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save command. Please try again.",
        variant: "destructive",
      });
    },
  });

  const generateCommandMutation = useMutation({
    mutationFn: async (description: string) => {
      const response = await apiRequest("POST", "/api/bots/default-bot/commands/generate", {
        description
      });
      return response.json();
    },
    onSuccess: (generatedCommand) => {
      setCommand(prev => ({
        ...prev,
        name: generatedCommand.name,
        response: generatedCommand.response,
        description: aiDescription,
      }));
      toast({
        title: "Command Generated",
        description: "AI has created a new command based on your description!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate command. Make sure your Groq API key is set.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (!command.name.trim() || !command.response.trim()) {
      toast({
        title: "Error",
        description: "Command name and response are required.",
        variant: "destructive",
      });
      return;
    }
    saveCommandMutation.mutate(command);
  };

  const handleGenerateCommand = () => {
    if (!aiDescription.trim()) {
      toast({
        title: "Error",
        description: "Please describe the command you want to create.",
        variant: "destructive",
      });
      return;
    }
    generateCommandMutation.mutate(aiDescription);
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl text-pink-400 font-bold">
            {editingCommand ? "Edit Command" : "Create New Command"}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* AI Command Generator */}
        {!editingCommand && (
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
            <div className="flex items-center mb-3">
              <Bot className="w-5 h-5 text-green-400 mr-2" />
              <h3 className="text-lg font-bold text-green-400">AI Command Generator</h3>
            </div>
            <div className="space-y-3">
              <Textarea
                value={aiDescription}
                onChange={(e) => setAiDescription(e.target.value)}
                className="form-field resize-none"
                rows={3}
                placeholder="e.g., 'Create a command that makes Sinder ask for treats when she's being good'"
              />
              <Button 
                onClick={handleGenerateCommand}
                disabled={generateCommandMutation.isPending}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500"
              >
                {generateCommandMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Wand2 className="mr-2 h-4 w-4" />
                )}
                Generate with AI
              </Button>
            </div>
          </div>
        )}

        {/* Manual Command Form */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-gray-300 mb-2 block">Command Name</Label>
            <Input
              value={command.name}
              onChange={(e) => setCommand(prev => ({ ...prev, name: e.target.value.replace(/[^a-zA-Z0-9]/g, '') }))}
              className="form-field"
              placeholder="cuddle"
              maxLength={20}
            />
          </div>

          <div>
            <Label className="text-gray-300 mb-2 block">Category</Label>
            <Select value={command.category} onValueChange={(value) => setCommand(prev => ({ ...prev, category: value }))}>
              <SelectTrigger className="form-field">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="emotion">Emotion</SelectItem>
                <SelectItem value="nsfw">NSFW</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label className="text-gray-300 mb-2 block">Description</Label>
          <Input
            value={command.description}
            onChange={(e) => setCommand(prev => ({ ...prev, description: e.target.value }))}
            className="form-field"
            placeholder="Makes Sinder ask for cuddles"
          />
        </div>

        <div>
          <Label className="text-gray-300 mb-2 block">Response</Label>
          <Textarea
            value={command.response}
            onChange={(e) => setCommand(prev => ({ ...prev, response: e.target.value }))}
            className="form-field resize-none"
            rows={4}
            placeholder="*perks up ears excitedly* Master wants cuddles?! *rushes over and nuzzles against you* I've been waiting for this all day! 🥺💕"
          />
          <p className="text-xs text-gray-500 mt-1">
            You can use variables like {"{name}"} for the bot's name, {"{neediness}"} for personality traits
          </p>
        </div>

        {/* Preview */}
        {command.response && (
          <div>
            <Label className="text-gray-300 mb-2 block">Preview</Label>
            <div className="bg-slate-800/50 rounded-lg p-4 border border-purple-500/30">
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm">🐱</span>
                </div>
                <div className="bg-purple-500/20 rounded-lg px-3 py-2 max-w-xs">
                  <p className="text-sm text-white">{command.response}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="flex space-x-4">
          <Button 
            onClick={handleSave}
            disabled={saveCommandMutation.isPending}
            className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500"
          >
            {saveCommandMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            {editingCommand ? "Update Command" : "Create Command"}
          </Button>
          <Button variant="outline" onClick={onClose} className="btn-ghost">
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
