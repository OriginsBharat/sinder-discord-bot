import { Link, useLocation } from "wouter";
import { Cat, Heart, Wand2, Brain, Images, Settings, Home } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();
  
  const { data: bot } = useQuery({
    queryKey: ["/api/bots/default-bot"],
  });

  const { data: status } = useQuery({
    queryKey: ["/api/bots/default-bot/status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const navItems = [
    { path: "/", icon: Home, label: "Dashboard" },
    { path: "/personality", icon: Heart, label: "Personality Editor" },
    { path: "/commands", icon: Wand2, label: "Command Builder" },
    { path: "/memory", icon: Brain, label: "Memory Bank" },
    { path: "/gallery", icon: Images, label: "Image Gallery" },
    { path: "/servers", icon: Settings, label: "Server Manager" },
    { path: "/settings", icon: Settings, label: "API Settings" },
  ];

  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-purple-500/20 to-pink-500/20 backdrop-blur-xl border-r border-purple-500/30">
      <div className="flex flex-col h-full">
        {/* Bot Avatar and Status */}
        <div className="p-6 border-b border-purple-500/30">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center animate-pulse-slow">
              <Cat className="text-white text-xl" />
            </div>
            <div>
              <h2 className="font-bold text-lg bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                {bot?.name || "Sinder"}
              </h2>
              <div className="flex items-center space-x-2">
                <div className={cn(
                  "w-2 h-2 rounded-full animate-bounce-gentle",
                  status?.status === "online" ? "bg-green-400" : "bg-red-400"
                )} />
                <span className="text-xs text-gray-300 capitalize">
                  {status?.status || "Offline"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <div className={cn(
                  "nav-item",
                  isActive && "active bg-gradient-to-r from-pink-500/20 to-purple-500/20 border border-pink-500/30"
                )}>
                  <Icon className={cn(
                    "text-pink-400 group-hover:scale-110 transition-transform",
                    isActive && "text-pink-300 scale-110"
                  )} />
                  <span className="text-white">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-purple-500/30">
          <Link href="/settings">
            <button className="w-full bg-gradient-to-r from-pink-400 to-purple-500 text-white py-2 px-4 rounded-xl hover:scale-105 transition-transform font-medium">
              <Settings className="inline mr-2" size={16} />
              Setup Bot
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
