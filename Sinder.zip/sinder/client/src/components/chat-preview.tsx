import { Cat, User } from "lucide-react";

interface ChatPreviewProps {
  personality?: {
    neediness?: number;
    playfulness?: number;
    intelligence?: number;
    bratiness?: number;
    description?: string;
  };
}

export default function ChatPreview({ personality }: ChatPreviewProps) {
  const sampleMessages = [
    {
      type: "bot",
      message: "Master~ I missed you so much! *nuzzles* Can we cuddle? 🥺",
    },
    {
      type: "user",
      message: "Of course, come here!",
    },
    {
      type: "bot", 
      message: "*purrs loudly and curls up against you* This is perfect~ You're the best master ever! 💕",
    },
  ];

  return (
    <div className="bg-slate-800/50 rounded-xl p-4 h-64 overflow-y-auto">
      <div className="space-y-3">
        {sampleMessages.map((msg, index) => (
          <div 
            key={index}
            className={`flex items-start space-x-3 ${msg.type === 'user' ? 'justify-end' : ''}`}
          >
            {msg.type === 'bot' && (
              <div className="w-8 h-8 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                <Cat className="text-white text-sm" />
              </div>
            )}
            <div className={`chat-bubble ${msg.type} ${msg.type === 'user' ? 'order-first' : ''}`}>
              <p className="text-sm text-white">{msg.message}</p>
            </div>
            {msg.type === 'user' && (
              <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
                <User className="text-white text-sm" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
