import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { X, Save, Plus, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MemoryManagerProps {
  onClose: () => void;
  editingMemory?: any;
}

export default function MemoryManager({ onClose, editingMemory }: MemoryManagerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [memory, setMemory] = useState({
    type: "conversation",
    content: "",
    importance: 5,
    context: {},
  });

  const [contextKey, setContextKey] = useState("");
  const [contextValue, setContextValue] = useState("");

  useEffect(() => {
    if (editingMemory) {
      setMemory({
        type: editingMemory.type,
        content: editingMemory.content,
        importance: editingMemory.importance || 5,
        context: editingMemory.context || {},
      });
    }
  }, [editingMemory]);

  const saveMemoryMutation = useMutation({
    mutationFn: async (memoryData: any) => {
      return apiRequest("POST", "/api/bots/default-bot/memories", memoryData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/memories"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/memories/stats"] });
      toast({
        title: "Memory Added",
        description: "Memory has been successfully saved!",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save memory. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    if (!memory.content.trim()) {
      toast({
        title: "Error",
        description: "Memory content is required.",
        variant: "destructive",
      });
      return;
    }
    saveMemoryMutation.mutate(memory);
  };

  const addContextPair = () => {
    if (!contextKey.trim() || !contextValue.trim()) {
      toast({
        title: "Error",
        description: "Both context key and value are required.",
        variant: "destructive",
      });
      return;
    }
    
    setMemory(prev => ({
      ...prev,
      context: {
        ...prev.context,
        [contextKey]: contextValue
      }
    }));
    
    setContextKey("");
    setContextValue("");
  };

  const removeContextPair = (key: string) => {
    setMemory(prev => {
      const newContext = { ...prev.context };
      delete newContext[key];
      return { ...prev, context: newContext };
    });
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "conversation": return "text-blue-400";
      case "emotion": return "text-pink-400";
      case "preference": return "text-purple-400";
      case "event": return "text-green-400";
      default: return "text-gray-400";
    }
  };

  const getImportanceLabel = (importance: number) => {
    if (importance >= 8) return "Critical";
    if (importance >= 6) return "Important";
    if (importance >= 4) return "Normal";
    if (importance >= 2) return "Low";
    return "Minimal";
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl text-pink-400 font-bold">
            {editingMemory ? "Edit Memory" : "Add New Memory"}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Memory Type and Importance */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-gray-300 mb-2 block">Memory Type</Label>
            <Select 
              value={memory.type} 
              onValueChange={(value) => setMemory(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger className="form-field">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conversation">Conversation</SelectItem>
                <SelectItem value="emotion">Emotion</SelectItem>
                <SelectItem value="preference">Preference</SelectItem>
                <SelectItem value="event">Event</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-gray-300 mb-2 block">
              Importance: {memory.importance}/10 ({getImportanceLabel(memory.importance)})
            </Label>
            <Slider
              value={[memory.importance]}
              onValueChange={([value]) => setMemory(prev => ({ ...prev, importance: value }))}
              max={10}
              min={1}
              step={1}
              className="personality-slider"
            />
          </div>
        </div>

        {/* Memory Content */}
        <div>
          <Label className="text-gray-300 mb-2 block">Memory Content</Label>
          <Textarea
            value={memory.content}
            onChange={(e) => setMemory(prev => ({ ...prev, content: e.target.value }))}
            className="form-field resize-none"
            rows={4}
            placeholder="What should Sinder remember? Be specific and detailed..."
          />
        </div>

        {/* Context Management */}
        <div>
          <Label className="text-gray-300 mb-2 block">Context (Optional)</Label>
          
          {/* Add Context Pair */}
          <div className="grid grid-cols-2 gap-2 mb-3">
            <Input
              value={contextKey}
              onChange={(e) => setContextKey(e.target.value)}
              className="form-field"
              placeholder="Key (e.g., userId)"
            />
            <div className="flex space-x-2">
              <Input
                value={contextValue}
                onChange={(e) => setContextValue(e.target.value)}
                className="form-field flex-1"
                placeholder="Value (e.g., 123456789)"
              />
              <Button 
                onClick={addContextPair}
                size="sm"
                className="bg-green-500/20 hover:bg-green-500/30 border border-green-500/40 text-green-400"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Existing Context Pairs */}
          {Object.keys(memory.context).length > 0 && (
            <div className="bg-slate-800/50 rounded-lg p-3 border border-purple-500/30">
              <h4 className="text-sm font-medium text-gray-300 mb-2">Context Data:</h4>
              <div className="space-y-2">
                {Object.entries(memory.context).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between p-2 bg-purple-500/10 rounded">
                    <span className="text-sm text-gray-300">
                      <span className="text-purple-400 font-medium">{key}:</span> {String(value)}
                    </span>
                    <Button
                      onClick={() => removeContextPair(key)}
                      size="sm"
                      variant="ghost"
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Memory Preview */}
        <div className="bg-slate-800/50 rounded-xl p-4 border border-purple-500/30">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Memory Preview:</h4>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className={`text-sm font-medium capitalize ${getTypeColor(memory.type)}`}>
                {memory.type}
              </span>
              <span className="text-xs text-gray-500">•</span>
              <span className="text-xs text-yellow-400">
                {getImportanceLabel(memory.importance)} Priority
              </span>
            </div>
            <p className="text-sm text-gray-300">{memory.content || "No content yet..."}</p>
            {Object.keys(memory.context).length > 0 && (
              <div className="text-xs text-gray-500">
                Context: {Object.keys(memory.context).length} fields
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-4">
          <Button 
            onClick={handleSave}
            disabled={saveMemoryMutation.isPending}
            className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500"
          >
            {saveMemoryMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            {editingMemory ? "Update Memory" : "Save Memory"}
          </Button>
          <Button variant="outline" onClick={onClose} className="btn-ghost">
            Cancel
          </Button>
        </div>

        {/* Memory Guidelines */}
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
          <h4 className="text-blue-400 font-bold mb-2">Memory Guidelines:</h4>
          <ul className="text-sm text-gray-300 space-y-1 list-disc list-inside">
            <li><strong>Conversations:</strong> Important dialogue or interactions</li>
            <li><strong>Emotions:</strong> Feelings, moods, or emotional states</li>
            <li><strong>Preferences:</strong> Likes, dislikes, or personal choices</li>
            <li><strong>Events:</strong> Significant happenings or milestones</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
