import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, MessageCircle, Database, Server, Heart, Wand2, Brain, Image, Edit, Loader2, Power, PowerOff, ExternalLink, Zap } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ChatPreview from "@/components/chat-preview";
import PersonalityEditor from "@/components/personality-editor";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: bot, isLoading: botLoading } = useQuery({
    queryKey: ["/api/bots/default-bot"],
  });

  const { data: status, isLoading: statusLoading } = useQuery({
    queryKey: ["/api/bots/default-bot/status"],
    refetchInterval: 30000,
  });

  const { data: memoryStats } = useQuery({
    queryKey: ["/api/bots/default-bot/memories/stats"],
  });

  const { data: inviteUrl } = useQuery({
    queryKey: ["/api/bots/default-bot/invite-url"],
  });

  const { data: imageModelStats } = useQuery({
    queryKey: ["/api/ai/image/models/stats"],
    refetchInterval: 60000,
  });

  const startBotMutation = useMutation({
    mutationFn: () => fetch("/api/bots/default-bot/start", { method: "POST" }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/status"] });
      toast({
        title: "Bot Started",
        description: "Sinder is now online and ready to serve! 🐱",
      });
    },
    onError: () => {
      toast({
        title: "Failed to Start Bot",
        description: "Check your Discord token and try again.",
        variant: "destructive",
      });
    }
  });

  const stopBotMutation = useMutation({
    mutationFn: () => fetch("/api/bots/default-bot/stop", { method: "POST" }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/status"] });
      toast({
        title: "Bot Stopped",
        description: "Sinder is now offline.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to Stop Bot",
        description: "There was an error stopping the bot.",
        variant: "destructive",
      });
    }
  });

  if (botLoading || statusLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  const statusData = status as any;
  const botData = bot as any;
  const memoryData = memoryStats as any;
  const inviteData = inviteUrl as any;
  const imageModelsData = imageModelStats as any;

  const statusColor = statusData?.status === "online" ? "green" : statusData?.status === "error" ? "red" : "gray";

  return (
    <div className="space-y-8">
      {/* Status Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Bot Status Card with Control Button */}
        <Card className={cn(
          "glass-card",
          statusData?.status === "online" ? "bg-green-500/10 border-green-500/30" : "bg-gray-500/10 border-gray-500/30"
        )}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className={cn(
                  "text-sm font-medium",
                  statusData?.status === "online" ? "text-green-400" : "text-gray-400"
                )}>Bot Status</p>
                <p className="text-2xl font-bold text-white mt-1 capitalize">
                  {statusData?.status || "Offline"}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                <CheckCircle className={cn(
                  statusData?.status === "online" ? "text-green-400" : "text-gray-400"
                )} />
              </div>
            </div>
            <div className="mt-4">
              {statusData?.status === "online" ? (
                <Button
                  onClick={() => stopBotMutation.mutate()}
                  disabled={stopBotMutation.isPending}
                  className="w-full bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400"
                  size="sm"
                >
                  {stopBotMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <PowerOff className="w-4 h-4 mr-2" />
                  )}
                  Stop Bot
                </Button>
              ) : (
                <Button
                  onClick={() => startBotMutation.mutate()}
                  disabled={startBotMutation.isPending}
                  className="w-full bg-green-500/20 hover:bg-green-500/30 border border-green-500/40 text-green-400"
                  size="sm"
                >
                  {startBotMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Power className="w-4 h-4 mr-2" />
                  )}
                  Start Bot
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Server Count */}
        <Card className="glass-card bg-purple-500/10 border-purple-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-400 text-sm font-medium">Active Servers</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {statusData?.serverCount || 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <Server className="text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Memory Usage */}
        <Card className="glass-card bg-blue-500/10 border-blue-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-400 text-sm font-medium">Total Memories</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {memoryData?.total || 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <Database className="text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Messages Today */}
        <Card className="glass-card bg-pink-500/10 border-pink-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-pink-400 text-sm font-medium">Conversations</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {memoryData?.conversations || 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-pink-500/20 rounded-xl flex items-center justify-center">
                <MessageCircle className="text-pink-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Models Status */}
      <Card className="glass-card bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-cyan-400 font-bold flex items-center">
            <Zap className="mr-2" />
            Free Uncensored AI Image Models ({imageModelsData?.totalModels || 4} Available)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-gray-300">
            Multiple free uncensored AI image generation models with automatic failover for unlimited /draw commands.
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {imageModelsData?.models?.map((model: any, index: number) => (
              <div key={index} className="bg-black/20 rounded-lg p-3 border border-cyan-500/20">
                <div className="flex items-center justify-between">
                  <span className="text-cyan-400 font-medium text-sm">{model.name}</span>
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">{model.description}</div>
                <div className="text-xs text-green-400 mt-1">✓ Free & Uncensored</div>
              </div>
            )) || (
              <>
                <div className="bg-black/20 rounded-lg p-3 border border-cyan-500/20">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-medium text-sm">Pollinations AI</span>
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">Completely free unlimited uncensored generation</div>
                  <div className="text-xs text-green-400 mt-1">✓ Free & Unlimited & Uncensored</div>
                </div>
                <div className="bg-black/20 rounded-lg p-3 border border-cyan-500/20">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-medium text-sm">ImgnAI</span>
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">Free unlimited uncensored API</div>
                  <div className="text-xs text-green-400 mt-1">✓ Free & Unlimited & Uncensored</div>
                </div>
                <div className="bg-black/20 rounded-lg p-3 border border-cyan-500/20">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-medium text-sm">Stable Horde</span>
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">Community-driven free uncensored generation</div>
                  <div className="text-xs text-green-400 mt-1">✓ Free & Unlimited & Uncensored</div>
                </div>
                <div className="bg-black/20 rounded-lg p-3 border border-cyan-500/20">
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-medium text-sm">HuggingFace SD 1.5</span>
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">Free tier Stable Diffusion fallback</div>
                  <div className="text-xs text-green-400 mt-1">✓ Free & Uncensored</div>
                </div>
              </>
            )}
          </div>
          
          <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
            <div className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
              <span className="text-green-400 font-medium">All Models Ready - Auto Failover Enabled</span>
            </div>
            <div className="text-sm text-gray-300 mt-1">
              When one model hits limits, automatically switches to the next. Unlimited uncensored /draw commands!
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Discord Invite Section */}
      <Card className="glass-card bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border-indigo-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-indigo-400 font-bold flex items-center">
            <ExternalLink className="mr-2" />
            Add Sinder to Your Discord Server
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-300">
            Invite Sinder to your Discord server to start chatting with your catgirl succubus bot!
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              onClick={() => window.open(inviteData?.url, '_blank')}
              className="bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-400 flex-1"
              disabled={!inviteData?.url}
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Invite to Discord Server
            </Button>
            <Button
              onClick={() => navigator.clipboard.writeText(inviteData?.url || '')}
              variant="outline"
              className="bg-purple-500/20 hover:bg-purple-500/30 border-purple-500/40 text-purple-400"
              disabled={!inviteData?.url}
            >
              Copy Invite Link
            </Button>
          </div>
          {inviteData?.url && (
            <div className="bg-black/20 rounded-lg p-3 font-mono text-sm text-gray-400 break-all">
              {inviteData.url}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Main Dashboard Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Personality Preview */}
        <div className="lg:col-span-2">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl text-pink-400 font-bold">
                  Live Personality Preview
                </CardTitle>
                <Button variant="outline" className="bg-purple-500/20 hover:bg-purple-500/30 border-purple-500/40">
                  <Edit className="mr-2" size={16} />
                  Edit
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <ChatPreview personality={botData?.personality} />
              
              {/* Personality Traits Display */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="bg-pink-500/20 rounded-lg p-3 text-center border border-pink-500/30">
                  <div className="text-pink-400 font-medium text-sm">Neediness</div>
                  <div className="text-2xl font-bold text-white">
                    {botData?.personality?.neediness || 95}%
                  </div>
                </div>
                <div className="bg-purple-500/20 rounded-lg p-3 text-center border border-purple-500/30">
                  <div className="text-purple-400 font-medium text-sm">Playfulness</div>
                  <div className="text-2xl font-bold text-white">
                    {botData?.personality?.playfulness || 88}%
                  </div>
                </div>
                <div className="bg-yellow-500/20 rounded-lg p-3 text-center border border-yellow-500/30">
                  <div className="text-yellow-400 font-medium text-sm">Intelligence</div>
                  <div className="text-2xl font-bold text-white">
                    {botData?.personality?.intelligence || 92}%
                  </div>
                </div>
                <div className="bg-red-500/20 rounded-lg p-3 text-center border border-red-500/30">
                  <div className="text-red-400 font-medium text-sm">Bratiness</div>
                  <div className="text-2xl font-bold text-white">
                    {botData?.personality?.bratiness || 75}%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          
          {/* Quick Actions */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg text-purple-400 font-bold">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <Button className="bg-gradient-to-r from-pink-500 to-purple-500 p-3 rounded-xl hover:scale-105 transition-transform text-center flex flex-col items-center">
                  <Heart className="mb-2" />
                  <span className="text-sm font-medium">Send Love</span>
                </Button>
                <Button className="bg-gradient-to-r from-purple-500 to-blue-500 p-3 rounded-xl hover:scale-105 transition-transform text-center flex flex-col items-center">
                  <Wand2 className="mb-2" />
                  <span className="text-sm font-medium">New Command</span>
                </Button>
                <Button className="bg-gradient-to-r from-green-500 to-teal-500 p-3 rounded-xl hover:scale-105 transition-transform text-center flex flex-col items-center">
                  <Brain className="mb-2" />
                  <span className="text-sm font-medium">Edit Memory</span>
                </Button>
                <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 p-3 rounded-xl hover:scale-105 transition-transform text-center flex flex-col items-center">
                  <Image className="mb-2" />
                  <span className="text-sm font-medium">Generate Art</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Memory Stats */}
          <Card className="glass-card bg-blue-500/10 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-lg text-blue-400 font-bold">Memory Bank</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-400">
                    {memoryData?.conversations || 0}
                  </div>
                  <div className="text-xs text-gray-400">Conversations</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-400">
                    {memoryData?.emotions || 0}
                  </div>
                  <div className="text-xs text-gray-400">Emotions</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-blue-400">
                    {memoryData?.preferences || 0}
                  </div>
                  <div className="text-xs text-gray-400">Preferences</div>
                </div>
              </div>
              
              <Button className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 text-white py-3 px-6 rounded-xl hover:scale-105 transition-transform font-medium">
                <Brain className="mr-2" size={16} />
                Manage Memory Bank
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Setup Guide Section */}
      <Card className="glass-card bg-green-500/10 border-green-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-green-400 font-bold">Setup Guide</CardTitle>
            <div className="bg-green-500/20 px-3 py-1 rounded-full border border-green-500/40">
              <span className="text-xs text-green-400">Beginner Friendly</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-slate-800/50 rounded-xl p-6 border border-green-500/30">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mb-4">
                <span className="text-green-400 font-bold text-xl">1</span>
              </div>
              <h4 className="font-bold text-green-400 mb-2">Get API Keys</h4>
              <p className="text-sm text-gray-300 mb-4">
                Obtain your Discord Bot Token, Groq API key, and Hugging Face token.
              </p>
              <Button className="bg-green-500/20 hover:bg-green-500/30 px-4 py-2 rounded-lg transition-colors text-sm">
                Get Keys
              </Button>
            </div>
            
            {/* Step 2 */}
            <div className="bg-slate-800/50 rounded-xl p-6 border border-green-500/30">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mb-4">
                <span className="text-green-400 font-bold text-xl">2</span>
              </div>
              <h4 className="font-bold text-green-400 mb-2">Configure Bot</h4>
              <p className="text-sm text-gray-300 mb-4">
                Enter your API keys and customize Sinder's personality settings.
              </p>
              <Button className="bg-green-500/20 hover:bg-green-500/30 px-4 py-2 rounded-lg transition-colors text-sm">
                Configure
              </Button>
            </div>
            
            {/* Step 3 */}
            <div className="bg-slate-800/50 rounded-xl p-6 border border-green-500/30">
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mb-4">
                <span className="text-green-400 font-bold text-xl">3</span>
              </div>
              <h4 className="font-bold text-green-400 mb-2">Invite to Server</h4>
              <p className="text-sm text-gray-300 mb-4">
                Add Sinder to your Discord server and start chatting!
              </p>
              <Button className="bg-green-500/20 hover:bg-green-500/30 px-4 py-2 rounded-lg transition-colors text-sm">
                Invite Bot
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
