import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Server, Users, Plus, ExternalLink, Trash2, Loader2, Bot, Copy, Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Servers() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [inviteUrl, setInviteUrl] = useState("");
  const [copiedInvite, setCopiedInvite] = useState(false);

  const { data: bot } = useQuery({
    queryKey: ["/api/bots/default-bot"],
  });

  const { data: servers, isLoading } = useQuery({
    queryKey: ["/api/bots/default-bot/servers"],
  });

  const { data: status } = useQuery({
    queryKey: ["/api/bots/default-bot/status"],
    refetchInterval: 30000,
  });

  const startBotMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/bots/default-bot/start");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/status"] });
      toast({
        title: "Bot Started",
        description: "Sinder is now online and ready to chat!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start bot. Please check your Discord token in settings.",
        variant: "destructive",
      });
    },
  });

  const stopBotMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/bots/default-bot/stop");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/status"] });
      toast({
        title: "Bot Stopped",
        description: "Sinder has been taken offline.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to stop bot. Please try again.",
        variant: "destructive",
      });
    },
  });

  const generateInviteUrl = () => {
    if (!bot?.token) {
      toast({
        title: "Error",
        description: "Bot token is required. Please configure it in settings first.",
        variant: "destructive",
      });
      return;
    }

    // Generate Discord bot invite URL with necessary permissions
    const permissions = [
      "2048",    // Send Messages
      "35840",   // Read Message History
      "268435456", // Use Slash Commands
      "137439936768", // Send Messages in Threads
    ].join("");

    const clientId = "YOUR_CLIENT_ID"; // This would need to be extracted from the bot token or configured
    const url = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=${permissions}&scope=bot%20applications.commands`;
    
    setInviteUrl(url);
    setShowInviteDialog(true);
  };

  const copyInviteUrl = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      setCopiedInvite(true);
      setTimeout(() => setCopiedInvite(false), 2000);
      toast({
        title: "Copied!",
        description: "Invite URL has been copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy invite URL.",
        variant: "destructive",
      });
    }
  };

  const handleStartBot = () => {
    if (!bot?.token) {
      toast({
        title: "Error",
        description: "Please configure your Discord bot token in settings first.",
        variant: "destructive",
      });
      return;
    }
    startBotMutation.mutate();
  };

  const handleStopBot = () => {
    stopBotMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Server Manager
        </h1>
        <div className="flex space-x-4">
          <Button 
            onClick={generateInviteUrl}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:scale-105 transition-transform"
          >
            <Plus className="mr-2 h-4 w-4" />
            Generate Invite
          </Button>
          <div className="bg-green-500/20 border border-green-500/40 rounded-xl px-4 py-2 flex items-center">
            <CheckCircle className="mr-2 h-4 w-4 text-green-400" />
            <span className="text-green-400 text-sm font-medium">24/7 Always Online</span>
          </div>
        </div>
      </div>

      {/* Bot Status Card */}
      <Card className={`glass-card ${
        status?.status === "online" 
          ? "bg-green-500/10 border-green-500/30" 
          : "bg-red-500/10 border-red-500/30"
      }`}>
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center">
            <Bot className={`mr-2 ${
              status?.status === "online" ? "text-green-400" : "text-red-400"
            }`} />
            Bot Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className={`text-3xl font-bold ${
                status?.status === "online" ? "text-green-400" : "text-red-400"
              }`}>
                {status?.status === "online" ? "ONLINE" : "OFFLINE"}
              </div>
              <div className="text-sm text-gray-400">Current Status</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400">
                {status?.serverCount || 0}
              </div>
              <div className="text-sm text-gray-400">Active Servers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-400">
                {bot?.name || "Sinder"}
              </div>
              <div className="text-sm text-gray-400">Bot Name</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invite Dialog */}
      <Dialog open={showInviteDialog} onOpenChange={setShowInviteDialog}>
        <DialogContent className="glass-card border-purple-500/30">
          <DialogHeader>
            <DialogTitle className="text-xl text-pink-400 font-bold flex items-center">
              <Plus className="mr-2" />
              Invite Bot to Server
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300 mb-2 block">
                Discord Bot Invite URL
              </Label>
              <div className="flex space-x-2">
                <Input
                  value={inviteUrl}
                  readOnly
                  className="form-field flex-1"
                  placeholder="Configure your bot first to generate invite URL"
                />
                <Button 
                  onClick={copyInviteUrl}
                  disabled={!inviteUrl}
                  className="bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40"
                >
                  {copiedInvite ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
              <h4 className="text-blue-400 font-bold mb-2">Instructions:</h4>
              <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                <li>Copy the invite URL above</li>
                <li>Open the URL in your browser</li>
                <li>Select the Discord server you want to add Sinder to</li>
                <li>Review the permissions and click "Authorize"</li>
                <li>Start the bot from this dashboard</li>
              </ol>
            </div>

            <div className="flex space-x-4">
              <Button 
                onClick={() => inviteUrl && window.open(inviteUrl, '_blank')}
                disabled={!inviteUrl}
                className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500"
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Open Invite URL
              </Button>
              <Button variant="outline" onClick={() => setShowInviteDialog(false)} className="btn-ghost">
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Server List */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-xl text-purple-400 font-bold">
            Connected Servers
          </CardTitle>
        </CardHeader>
        <CardContent>
          {servers && servers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {servers.map((server: any) => (
                <Card key={server.id} className="glass-card">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-400 rounded-xl flex items-center justify-center">
                          <Server className="text-white" size={20} />
                        </div>
                        <div>
                          <h3 className="font-bold text-white">{server.name}</h3>
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${
                              server.active ? "bg-green-400" : "bg-red-400"
                            }`} />
                            <span className="text-xs text-gray-400">
                              {server.active ? "Active" : "Inactive"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-400">Members:</span>
                        <span className="text-sm text-white font-medium">
                          {server.memberCount || 0}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-400">Added:</span>
                        <span className="text-sm text-white font-medium">
                          {new Date(server.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between">
                      <Switch 
                        checked={server.active}
                        disabled
                        className="data-[state=checked]:bg-green-500"
                      />
                      {server.inviteUrl && (
                        <Button
                          onClick={() => window.open(server.inviteUrl, '_blank')}
                          size="sm"
                          className="bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/40"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Server className="w-16 h-16 text-gray-500 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-400 mb-2">No Servers Connected</h3>
              <p className="text-gray-500 mb-6">
                Generate an invite link and add Sinder to your Discord servers to get started.
              </p>
              <Button 
                onClick={generateInviteUrl}
                className="bg-gradient-to-r from-purple-500 to-blue-500"
              >
                <Plus className="mr-2 h-4 w-4" />
                Generate Invite Link
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Setup Guide */}
      <Card className="glass-card bg-blue-500/10 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-blue-400 font-bold">
            Quick Setup Guide
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold text-blue-400 mb-2">For New Bots:</h4>
              <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                <li>Go to Discord Developer Portal</li>
                <li>Create a new application and bot</li>
                <li>Copy the bot token to Settings</li>
                <li>Generate and use the invite link</li>
              </ol>
            </div>
            <div>
              <h4 className="font-bold text-blue-400 mb-2">For Existing Bots:</h4>
              <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                <li>Enter your bot token in Settings</li>
                <li>Start the bot from this page</li>
                <li>Use existing invites or generate new ones</li>
                <li>Configure personality and commands</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
