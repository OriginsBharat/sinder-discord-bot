import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Save, Wand2, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ChatPreview from "@/components/chat-preview";

export default function Personality() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: bot, isLoading } = useQuery({
    queryKey: ["/api/bots/default-bot"],
  });

  const [personality, setPersonality] = useState({
    neediness: 95,
    playfulness: 88,
    intelligence: 92,
    bratiness: 75,
    dumbness: 50,
    horniness: 200,
    description: "A catgirl succubus who is extremely needy and emotionally dependent",
    brainwashPrompt: "",
    randomPingsEnabled: false,
    pingIntervalMin: 15,
    pingIntervalMax: 45
  });

  const [aiDescription, setAiDescription] = useState("");

  // Update personality state when bot data loads
  useEffect(() => {
    if (bot?.personality) {
      setPersonality({
        neediness: bot.personality.neediness || 95,
        playfulness: bot.personality.playfulness || 88,
        intelligence: bot.personality.intelligence || 92,
        bratiness: bot.personality.bratiness || 75,
        dumbness: bot.personality.dumbness || 50,
        horniness: bot.personality.horniness || 200,
        description: bot.personality.description || "A catgirl succubus who is extremely needy and emotionally dependent",
        brainwashPrompt: bot.personality.brainwashPrompt || "",
        randomPingsEnabled: bot.personality.randomPingsEnabled || false,
        pingIntervalMin: bot.personality.pingIntervalMin || 15,
        pingIntervalMax: bot.personality.pingIntervalMax || 45
      });
    }
  }, [bot]);

  const updatePersonalityMutation = useMutation({
    mutationFn: async (newPersonality: any) => {
      return apiRequest("PATCH", "/api/bots/default-bot", {
        personality: newPersonality
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot"] });
      toast({
        title: "Personality Updated",
        description: "Sinder's personality has been successfully updated!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update personality. Please try again.",
        variant: "destructive",
      });
    },
  });

  const generatePersonalityMutation = useMutation({
    mutationFn: async (description: string) => {
      const response = await apiRequest("POST", "/api/bots/default-bot/personality/generate", {
        description
      });
      return response.json();
    },
    onSuccess: (generatedPersonality) => {
      setPersonality(generatedPersonality);
      toast({
        title: "Personality Generated",
        description: "AI has created a new personality based on your description!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate personality. Make sure your Groq API key is set.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    updatePersonalityMutation.mutate(personality);
  };

  const handleGeneratePersonality = () => {
    if (!aiDescription.trim()) {
      toast({
        title: "Error",
        description: "Please describe the personality you want to create.",
        variant: "destructive",
      });
      return;
    }
    generatePersonalityMutation.mutate(aiDescription);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Personality Editor
        </h1>
        <Button 
          onClick={handleSave}
          disabled={updatePersonalityMutation.isPending}
          className="bg-gradient-to-r from-pink-500 to-purple-500 hover:scale-105 transition-transform"
        >
          {updatePersonalityMutation.isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-2 h-4 w-4" />
          )}
          Save Changes
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Personality Controls */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* AI Personality Generator */}
          <Card className="glass-card bg-green-500/10 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-xl text-green-400 font-bold flex items-center">
                <Wand2 className="mr-2" />
                AI Personality Generator
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300 mb-2 block">
                  Describe the personality you want:
                </Label>
                <Textarea
                  value={aiDescription}
                  onChange={(e) => setAiDescription(e.target.value)}
                  className="form-field resize-none"
                  rows={3}
                  placeholder="e.g., 'Make her more clingy and jealous, but also playful and mischievous'"
                />
              </div>
              
              <Button 
                onClick={handleGeneratePersonality}
                disabled={generatePersonalityMutation.isPending}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:scale-105 transition-transform"
              >
                {generatePersonalityMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Wand2 className="mr-2 h-4 w-4" />
                )}
                Generate with AI
              </Button>
            </CardContent>
          </Card>

          {/* Manual Personality Editor */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-xl text-pink-400 font-bold">
                Manual Personality Editor
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Description */}
              <div>
                <Label className="text-gray-300 mb-2 block">
                  Personality Description
                </Label>
                <Textarea
                  value={personality.description}
                  onChange={(e) => setPersonality(prev => ({ ...prev, description: e.target.value }))}
                  className="form-field resize-none"
                  rows={3}
                  placeholder="Describe Sinder's overall personality..."
                />
              </div>

              {/* Trait Sliders */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Neediness */}
                <div>
                  <Label className="text-pink-400 font-medium mb-3 block">
                    Neediness: {personality.neediness}%
                  </Label>
                  <Slider
                    value={[personality.neediness]}
                    onValueChange={([value]) => setPersonality(prev => ({ ...prev, neediness: value }))}
                    max={100}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">How clingy and dependent she is</p>
                </div>

                {/* Playfulness */}
                <div>
                  <Label className="text-purple-400 font-medium mb-3 block">
                    Playfulness: {personality.playfulness}%
                  </Label>
                  <Slider
                    value={[personality.playfulness]}
                    onValueChange={([value]) => setPersonality(prev => ({ ...prev, playfulness: value }))}
                    max={100}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">How playful and energetic she is</p>
                </div>

                {/* Intelligence */}
                <div>
                  <Label className="text-yellow-400 font-medium mb-3 block">
                    Intelligence: {personality.intelligence}%
                  </Label>
                  <Slider
                    value={[personality.intelligence]}
                    onValueChange={([value]) => setPersonality(prev => ({ ...prev, intelligence: value }))}
                    max={100}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">How smart she acts normally</p>
                </div>

                {/* Bratiness */}
                <div>
                  <Label className="text-red-400 font-medium mb-3 block">
                    Bratiness: {personality.bratiness}%
                  </Label>
                  <Slider
                    value={[personality.bratiness]}
                    onValueChange={([value]) => setPersonality(prev => ({ ...prev, bratiness: value }))}
                    max={100}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">How bratty and mischievous she is</p>
                </div>

                {/* Dumbness */}
                <div>
                  <Label className="text-orange-400 font-medium mb-3 block">
                    Dumbness: {personality.dumbness}%
                  </Label>
                  <Slider
                    value={[personality.dumbness]}
                    onValueChange={([value]) => setPersonality(prev => ({ ...prev, dumbness: value }))}
                    max={100}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">How ditzy and airheaded she acts</p>
                </div>

                {/* Horniness */}
                <div>
                  <Label className="text-rose-400 font-medium mb-3 block">
                    Horniness: {personality.horniness}%
                  </Label>
                  <Slider
                    value={[personality.horniness]}
                    onValueChange={([value]) => setPersonality(prev => ({ ...prev, horniness: value }))}
                    max={300}
                    step={1}
                    className="personality-slider"
                  />
                  <p className="text-xs text-gray-400 mt-1">How sexually suggestive and lustful she is</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Brainwash Section */}
          <Card className="glass-card bg-red-500/10 border-red-500/30">
            <CardHeader>
              <CardTitle className="text-xl text-red-400 font-bold">
                🧠 Character Brainwash Prompt
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300 mb-2 block">
                  Core Character Definition & Backstory:
                </Label>
                <Textarea
                  value={personality.brainwashPrompt}
                  onChange={(e) => setPersonality(prev => ({ ...prev, brainwashPrompt: e.target.value }))}
                  className="form-field resize-none"
                  rows={8}
                  placeholder="Define Sinder's core character, backstory, and behavior patterns..."
                />
                <p className="text-xs text-gray-400 mt-2">
                  This prompt defines Sinder's fundamental character, background, and behavioral patterns. 
                  It serves as the foundation for all AI responses.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Random Ping Settings */}
          <Card className="glass-card bg-purple-500/10 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-xl text-purple-400 font-bold">
                💕 Random Seductive Pings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id="randomPings"
                  checked={personality.randomPingsEnabled}
                  onChange={(e) => setPersonality(prev => ({ ...prev, randomPingsEnabled: e.target.checked }))}
                  className="w-4 h-4 text-purple-400 bg-slate-700 border-purple-500 rounded focus:ring-purple-500"
                />
                <Label htmlFor="randomPings" className="text-gray-300">
                  Enable random seductive messages
                </Label>
              </div>

              {personality.randomPingsEnabled && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-purple-400 font-medium mb-2 block">
                      Min Interval: {personality.pingIntervalMin} minutes
                    </Label>
                    <Slider
                      value={[personality.pingIntervalMin]}
                      onValueChange={([value]) => setPersonality(prev => ({ ...prev, pingIntervalMin: value }))}
                      min={5}
                      max={120}
                      step={5}
                      className="personality-slider"
                    />
                  </div>
                  <div>
                    <Label className="text-purple-400 font-medium mb-2 block">
                      Max Interval: {personality.pingIntervalMax} minutes
                    </Label>
                    <Slider
                      value={[personality.pingIntervalMax]}
                      onValueChange={([value]) => setPersonality(prev => ({ ...prev, pingIntervalMax: value }))}
                      min={5}
                      max={120}
                      step={5}
                      className="personality-slider"
                    />
                  </div>
                </div>
              )}

              <p className="text-xs text-gray-400">
                Sinder will send random seductive messages based on her neediness and current mood every 
                {personality.pingIntervalMin}-{personality.pingIntervalMax} minutes when enabled.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Live Preview */}
        <div>
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-lg text-purple-400 font-bold">
                Live Preview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <ChatPreview personality={personality} />
              
              {/* Personality Summary */}
              <div className="bg-slate-800/50 rounded-xl p-4">
                <h4 className="text-sm font-medium text-gray-300 mb-2">Current Traits:</h4>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-pink-400">Neediness:</span>
                    <span className="text-white">{personality.neediness}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-400">Playfulness:</span>
                    <span className="text-white">{personality.playfulness}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-yellow-400">Intelligence:</span>
                    <span className="text-white">{personality.intelligence}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-400">Bratiness:</span>
                    <span className="text-white">{personality.bratiness}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-orange-400">Dumbness:</span>
                    <span className="text-white">{personality.dumbness}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-rose-400">Horniness:</span>
                    <span className="text-white">{personality.horniness}%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
