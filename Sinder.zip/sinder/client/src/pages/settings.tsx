import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, Eye, EyeOff, Key, Bot, Settings as SettingsIcon, Loader2, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [showTokens, setShowTokens] = useState(false);
  const [settings, setSettings] = useState({
    groqApiKey: "",
    huggingFaceKey: "",
    randomMessaging: true,
    nsfwEnabled: true,
  });
  const [botConfig, setBotConfig] = useState({
    name: "Sinder",
    token: "",
  });

  const { data: bot, isLoading } = useQuery({
    queryKey: ["/api/bots/default-bot"],
  });

  // Update state when bot data loads
  useEffect(() => {
    if (bot) {
      setSettings(bot.settings || {
        groqApiKey: "",
        huggingFaceKey: "",
        randomMessaging: true,
        nsfwEnabled: true,
      });
      setBotConfig({
        name: bot.name,
        token: bot.token,
      });
    }
  }, [bot]);

  const updateBotMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("PATCH", "/api/bots/default-bot", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot"] });
      toast({
        title: "Settings Saved",
        description: "Your bot configuration has been updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const testConnectionMutation = useMutation({
    mutationFn: async (apiType: string) => {
      // This would test the API connection
      return new Promise((resolve) => {
        setTimeout(() => resolve(true), 1000);
      });
    },
    onSuccess: (_, apiType) => {
      toast({
        title: "Connection Test",
        description: `${apiType} API connection successful!`,
      });
    },
    onError: (_, apiType) => {
      toast({
        title: "Connection Failed",
        description: `Failed to connect to ${apiType} API. Please check your key.`,
        variant: "destructive",
      });
    },
  });

  const handleSaveSettings = () => {
    updateBotMutation.mutate({ settings });
  };

  const handleSaveBotConfig = () => {
    updateBotMutation.mutate(botConfig);
  };

  const handleTestConnection = (apiType: string) => {
    testConnectionMutation.mutate(apiType);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Settings & Configuration
        </h1>
        <div className="flex items-center space-x-2">
          <Switch 
            checked={showTokens}
            onCheckedChange={setShowTokens}
          />
          <Label className="text-gray-400">Show API Keys</Label>
        </div>
      </div>

      <Tabs defaultValue="bot" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
          <TabsTrigger value="bot">Bot Configuration</TabsTrigger>
          <TabsTrigger value="api">API Keys</TabsTrigger>
          <TabsTrigger value="behavior">Behavior Settings</TabsTrigger>
        </TabsList>

        {/* Bot Configuration */}
        <TabsContent value="bot">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-xl text-pink-400 font-bold flex items-center">
                <Bot className="mr-2" />
                Discord Bot Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-gray-300 mb-2 block">Bot Name</Label>
                  <Input
                    value={botConfig.name}
                    onChange={(e) => setBotConfig(prev => ({ ...prev, name: e.target.value }))}
                    className="form-field"
                    placeholder="Sinder"
                  />
                </div>
                <div>
                  <Label className="text-gray-300 mb-2 block">Discord Bot Token</Label>
                  <div className="relative">
                    <Input
                      type={showTokens ? "text" : "password"}
                      value={botConfig.token}
                      onChange={(e) => setBotConfig(prev => ({ ...prev, token: e.target.value }))}
                      className="form-field pr-10"
                      placeholder="Your Discord bot token..."
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 -translate-y-1/2"
                      onClick={() => setShowTokens(!showTokens)}
                    >
                      {showTokens ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                <h4 className="text-blue-400 font-bold mb-2 flex items-center">
                  <SettingsIcon className="mr-2" size={16} />
                  How to get a Discord Bot Token:
                </h4>
                <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                  <li>Go to <a href="https://discord.com/developers/applications" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Discord Developer Portal</a></li>
                  <li>Click "New Application" and give it a name</li>
                  <li>Go to the "Bot" section in the left sidebar</li>
                  <li>Click "Add Bot" and confirm</li>
                  <li>Copy the token under "Token" section</li>
                  <li>Enable necessary intents (Message Content Intent, etc.)</li>
                </ol>
              </div>

              <Button 
                onClick={handleSaveBotConfig}
                disabled={updateBotMutation.isPending}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
              >
                {updateBotMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save Bot Configuration
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* API Keys */}
        <TabsContent value="api">
          <div className="space-y-6">
            
            {/* Groq API */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="text-xl text-green-400 font-bold flex items-center">
                  <Key className="mr-2" />
                  Groq API Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300 mb-2 block">Groq API Key</Label>
                  <div className="flex space-x-2">
                    <Input
                      type={showTokens ? "text" : "password"}
                      value={settings.groqApiKey}
                      onChange={(e) => setSettings(prev => ({ ...prev, groqApiKey: e.target.value }))}
                      className="form-field flex-1"
                      placeholder="gsk_..."
                    />
                    <Button 
                      onClick={() => handleTestConnection("Groq")}
                      disabled={!settings.groqApiKey || testConnectionMutation.isPending}
                      className="bg-green-500/20 hover:bg-green-500/30 border border-green-500/40 text-green-400"
                    >
                      {testConnectionMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <CheckCircle className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
                  <h4 className="text-green-400 font-bold mb-2">Get Groq API Key:</h4>
                  <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                    <li>Visit <a href="https://console.groq.com" target="_blank" rel="noopener noreferrer" className="text-green-400 hover:underline">Groq Console</a></li>
                    <li>Sign up or log in to your account</li>
                    <li>Go to API Keys section</li>
                    <li>Create a new API key</li>
                    <li>Copy and paste it above</li>
                  </ol>
                </div>
              </CardContent>
            </Card>

            {/* Hugging Face API */}
            <Card className="glass-card">
              <CardHeader>
                <CardTitle className="text-xl text-yellow-400 font-bold flex items-center">
                  <Key className="mr-2" />
                  Hugging Face API Configuration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-gray-300 mb-2 block">Hugging Face API Key</Label>
                  <div className="flex space-x-2">
                    <Input
                      type={showTokens ? "text" : "password"}
                      value={settings.huggingFaceKey}
                      onChange={(e) => setSettings(prev => ({ ...prev, huggingFaceKey: e.target.value }))}
                      className="form-field flex-1"
                      placeholder="hf_..."
                    />
                    <Button 
                      onClick={() => handleTestConnection("Hugging Face")}
                      disabled={!settings.huggingFaceKey || testConnectionMutation.isPending}
                      className="bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/40 text-yellow-400"
                    >
                      {testConnectionMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <CheckCircle className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
                  <h4 className="text-yellow-400 font-bold mb-2">Get Hugging Face API Key:</h4>
                  <ol className="text-sm text-gray-300 space-y-1 list-decimal list-inside">
                    <li>Visit <a href="https://huggingface.co" target="_blank" rel="noopener noreferrer" className="text-yellow-400 hover:underline">Hugging Face</a></li>
                    <li>Create an account and log in</li>
                    <li>Go to Settings → Access Tokens</li>
                    <li>Create a new token with "Write" permissions</li>
                    <li>Copy and paste it above</li>
                  </ol>
                </div>
              </CardContent>
            </Card>

            <Button 
              onClick={handleSaveSettings}
              disabled={updateBotMutation.isPending}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
            >
              {updateBotMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save API Keys
            </Button>
          </div>
        </TabsContent>

        {/* Behavior Settings */}
        <TabsContent value="behavior">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-xl text-purple-400 font-bold flex items-center">
                <SettingsIcon className="mr-2" />
                Bot Behavior Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-purple-500/30">
                  <div>
                    <h4 className="font-medium text-white">Random Messaging</h4>
                    <p className="text-sm text-gray-400">
                      Allow Sinder to send random messages and DMs when she's feeling needy
                    </p>
                  </div>
                  <Switch 
                    checked={settings.randomMessaging}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, randomMessaging: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl border border-red-500/30">
                  <div>
                    <h4 className="font-medium text-white">NSFW Content</h4>
                    <p className="text-sm text-gray-400">
                      Enable NSFW responses and image generation capabilities
                    </p>
                  </div>
                  <Switch 
                    checked={settings.nsfwEnabled}
                    onCheckedChange={(checked) => setSettings(prev => ({ ...prev, nsfwEnabled: checked }))}
                  />
                </div>
              </div>

              <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4">
                <div className="flex items-center mb-2">
                  <AlertCircle className="mr-2 text-orange-400" size={16} />
                  <h4 className="text-orange-400 font-bold">Important Notice</h4>
                </div>
                <p className="text-sm text-gray-300">
                  You are responsible for ensuring compliance with Discord's Terms of Service and your local laws. 
                  NSFW content should only be used in appropriate channels and with proper age verification.
                </p>
              </div>

              <Button 
                onClick={handleSaveSettings}
                disabled={updateBotMutation.isPending}
                className="w-full bg-gradient-to-r from-pink-500 to-purple-500"
              >
                {updateBotMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save Behavior Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Status Overview */}
      <Card className="glass-card bg-blue-500/10 border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-blue-400 font-bold">
            Configuration Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center space-x-2">
              {botConfig.token ? (
                <CheckCircle className="text-green-400" size={16} />
              ) : (
                <AlertCircle className="text-red-400" size={16} />
              )}
              <span className="text-sm">Discord Token</span>
            </div>
            <div className="flex items-center space-x-2">
              {settings.groqApiKey ? (
                <CheckCircle className="text-green-400" size={16} />
              ) : (
                <AlertCircle className="text-red-400" size={16} />
              )}
              <span className="text-sm">Groq API Key</span>
            </div>
            <div className="flex items-center space-x-2">
              {settings.huggingFaceKey ? (
                <CheckCircle className="text-green-400" size={16} />
              ) : (
                <AlertCircle className="text-red-400" size={16} />
              )}
              <span className="text-sm">Hugging Face Key</span>
            </div>
            <div className="flex items-center space-x-2">
              {botConfig.token && settings.groqApiKey ? (
                <CheckCircle className="text-green-400" size={16} />
              ) : (
                <AlertCircle className="text-red-400" size={16} />
              )}
              <span className="text-sm">Ready to Start</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
