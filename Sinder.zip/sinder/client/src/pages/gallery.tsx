import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Image as ImageIcon, Trash2, Download, Eye, Loader2, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Gallery() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [showGenerator, setShowGenerator] = useState(false);
  const [selectedImage, setSelectedImage] = useState<any>(null);
  const [filter, setFilter] = useState("all");
  
  const [imagePrompt, setImagePrompt] = useState("");
  const [imageCategory, setImageCategory] = useState("general");

  const { data: images, isLoading } = useQuery({
    queryKey: ["/api/bots/default-bot/images"],
  });

  const generateImageMutation = useMutation({
    mutationFn: async (data: { prompt: string; category: string }) => {
      const response = await apiRequest("POST", "/api/bots/default-bot/images/generate", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/images"] });
      setShowGenerator(false);
      setImagePrompt("");
      toast({
        title: "Image Generated",
        description: "Your AI-generated image has been created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate image. Make sure your Hugging Face API key is set.",
        variant: "destructive",
      });
    },
  });

  const deleteImageMutation = useMutation({
    mutationFn: async (imageId: string) => {
      return apiRequest("DELETE", `/api/images/${imageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/images"] });
      toast({
        title: "Image Deleted",
        description: "Image has been successfully removed!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerateImage = () => {
    if (!imagePrompt.trim()) {
      toast({
        title: "Error",
        description: "Please enter a prompt for the image.",
        variant: "destructive",
      });
      return;
    }
    generateImageMutation.mutate({ prompt: imagePrompt, category: imageCategory });
  };

  const handleDeleteImage = (imageId: string) => {
    if (confirm("Are you sure you want to delete this image?")) {
      deleteImageMutation.mutate(imageId);
    }
  };

  const handleDownloadImage = async (imageUrl: string, prompt: string) => {
    try {
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sinder-${prompt.slice(0, 20).replace(/[^a-zA-Z0-9]/g, '_')}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download image.",
        variant: "destructive",
      });
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "nsfw": return "bg-red-500/20 text-red-400 border-red-500/30";
      default: return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    }
  };

  const filteredImages = images?.filter((image: any) => 
    filter === "all" || image.category === filter
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Image Gallery
        </h1>
        <Button 
          onClick={() => setShowGenerator(true)}
          className="bg-gradient-to-r from-pink-500 to-purple-500 hover:scale-105 transition-transform"
        >
          <Plus className="mr-2 h-4 w-4" />
          Generate Image
        </Button>
      </div>

      {/* Image Generator Dialog */}
      <Dialog open={showGenerator} onOpenChange={setShowGenerator}>
        <DialogContent className="glass-card border-purple-500/30">
          <DialogHeader>
            <DialogTitle className="text-xl text-pink-400 font-bold flex items-center">
              <Sparkles className="mr-2" />
              AI Image Generator
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-gray-300 mb-2 block">Image Prompt</Label>
              <Textarea
                value={imagePrompt}
                onChange={(e) => setImagePrompt(e.target.value)}
                className="form-field resize-none"
                rows={4}
                placeholder="e.g., 'A cute catgirl with pink hair sitting in a cozy room, anime style, detailed'"
              />
            </div>
            
            <div>
              <Label className="text-gray-300 mb-2 block">Category</Label>
              <Select value={imageCategory} onValueChange={setImageCategory}>
                <SelectTrigger className="form-field">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General</SelectItem>
                  <SelectItem value="nsfw">NSFW</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex space-x-4">
              <Button 
                onClick={handleGenerateImage}
                disabled={generateImageMutation.isPending}
                className="flex-1 bg-gradient-to-r from-pink-500 to-purple-500"
              >
                {generateImageMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="mr-2 h-4 w-4" />
                )}
                Generate Image
              </Button>
              <Button variant="outline" onClick={() => setShowGenerator(false)} className="btn-ghost">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image View Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="glass-card border-purple-500/30 max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-xl text-pink-400 font-bold">
              Image Details
            </DialogTitle>
          </DialogHeader>
          {selectedImage && (
            <div className="space-y-4">
              <div className="relative">
                <img 
                  src={selectedImage.url} 
                  alt={selectedImage.prompt}
                  className="w-full h-auto max-h-96 object-contain rounded-xl"
                />
              </div>
              <div>
                <Label className="text-gray-300 text-sm">Prompt:</Label>
                <p className="text-white mt-1">{selectedImage.prompt}</p>
              </div>
              <div className="flex items-center justify-between">
                <Badge className={getCategoryColor(selectedImage.category)}>
                  {selectedImage.category}
                </Badge>
                <div className="flex space-x-2">
                  <Button
                    onClick={() => handleDownloadImage(selectedImage.url, selectedImage.prompt)}
                    className="bg-green-500/20 hover:bg-green-500/30 border border-green-500/40 text-green-400"
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                  <Button
                    onClick={() => handleDeleteImage(selectedImage.id)}
                    disabled={deleteImageMutation.isPending}
                    className="bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400"
                  >
                    {deleteImageMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Trash2 className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Filter Tabs */}
      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            {["all", "general", "nsfw"].map((category) => (
              <Button
                key={category}
                variant={filter === category ? "default" : "outline"}
                onClick={() => setFilter(category)}
                className={filter === category 
                  ? "bg-gradient-to-r from-pink-500 to-purple-500" 
                  : "btn-ghost"
                }
              >
                {category === "all" ? "All Images" : category.toUpperCase()}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Image Grid */}
      {filteredImages && filteredImages.length > 0 ? (
        <div className="gallery-grid">
          {filteredImages.map((image: any) => (
            <Card key={image.id} className="gallery-item glass-card overflow-hidden">
              <div className="relative group cursor-pointer" onClick={() => setSelectedImage(image)}>
                <img 
                  src={image.url} 
                  alt={image.prompt}
                  className="w-full h-full object-cover transition-transform group-hover:scale-110"
                />
                <div className="gallery-overlay">
                  <div className="flex items-center space-x-2">
                    <Button size="sm" className="bg-white/20 hover:bg-white/30">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownloadImage(image.url, image.prompt);
                      }}
                      className="bg-white/20 hover:bg-white/30"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteImage(image.id);
                      }}
                      disabled={deleteImageMutation.isPending}
                      className="bg-red-500/20 hover:bg-red-500/30"
                    >
                      {deleteImageMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-black/50 p-2">
                  <Badge className={getCategoryColor(image.category)}>
                    {image.category}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-3">
                <p className="text-sm text-gray-300 line-clamp-2">{image.prompt}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {new Date(image.createdAt).toLocaleDateString()}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="glass-card">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ImageIcon className="w-16 h-16 text-gray-500 mb-4" />
            <h3 className="text-xl font-bold text-gray-400 mb-2">No Images Yet</h3>
            <p className="text-gray-500 text-center mb-6">
              Generate your first AI image to get started! Use detailed prompts for better results.
            </p>
            <Button 
              onClick={() => setShowGenerator(true)}
              className="bg-gradient-to-r from-pink-500 to-purple-500"
            >
              <Plus className="mr-2 h-4 w-4" />
              Generate First Image
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
