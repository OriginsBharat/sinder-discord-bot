import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Plus, Trash2, Brain, Heart, MessageCircle, Calendar, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MemoryManager from "@/components/memory-manager";

export default function Memory() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddMemory, setShowAddMemory] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  const { data: memories, isLoading } = useQuery({
    queryKey: ["/api/bots/default-bot/memories", { type: activeTab === "all" ? undefined : activeTab }],
  });

  const { data: memoryStats } = useQuery({
    queryKey: ["/api/bots/default-bot/memories/stats"],
  });

  const { data: searchResults, refetch: searchMemories } = useQuery({
    queryKey: ["/api/bots/default-bot/memories/search", { q: searchQuery }],
    enabled: false,
  });

  const deleteMemoryMutation = useMutation({
    mutationFn: async (memoryId: string) => {
      return apiRequest("DELETE", `/api/memories/${memoryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/memories"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/memories/stats"] });
      toast({
        title: "Memory Deleted",
        description: "Memory has been successfully removed!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete memory. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    if (searchQuery.trim()) {
      searchMemories();
    }
  };

  const handleDeleteMemory = (memoryId: string) => {
    if (confirm("Are you sure you want to delete this memory?")) {
      deleteMemoryMutation.mutate(memoryId);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "conversation": return <MessageCircle className="w-4 h-4" />;
      case "emotion": return <Heart className="w-4 h-4" />;
      case "preference": return <Brain className="w-4 h-4" />;
      default: return <Calendar className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "conversation": return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "emotion": return "bg-pink-500/20 text-pink-400 border-pink-500/30";
      case "preference": return "bg-purple-500/20 text-purple-400 border-purple-500/30";
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/30";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  const displayedMemories = searchQuery.trim() ? searchResults : memories;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Memory Bank
        </h1>
        <Button 
          onClick={() => setShowAddMemory(true)}
          className="bg-gradient-to-r from-pink-500 to-purple-500 hover:scale-105 transition-transform"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Memory
        </Button>
      </div>

      {showAddMemory && (
        <MemoryManager onClose={() => setShowAddMemory(false)} />
      )}

      {/* Memory Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="glass-card bg-blue-500/10 border-blue-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-400 text-sm font-medium">Conversations</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {memoryStats?.conversations || 0}
                </p>
              </div>
              <MessageCircle className="text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card bg-pink-500/10 border-pink-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-pink-400 text-sm font-medium">Emotions</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {memoryStats?.emotions || 0}
                </p>
              </div>
              <Heart className="text-pink-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card bg-purple-500/10 border-purple-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-400 text-sm font-medium">Preferences</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {memoryStats?.preferences || 0}
                </p>
              </div>
              <Brain className="text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card bg-green-500/10 border-green-500/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-400 text-sm font-medium">Total</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {memoryStats?.total || 0}
                </p>
              </div>
              <Calendar className="text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="glass-card">
        <CardContent className="pt-6">
          <div className="flex space-x-4">
            <div className="flex-1">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="form-field"
                placeholder="Search memories..."
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch} className="bg-gradient-to-r from-blue-500 to-indigo-500">
              <Search className="mr-2 h-4 w-4" />
              Search
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Memory Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5 bg-slate-800/50">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="conversation">Conversations</TabsTrigger>
          <TabsTrigger value="emotion">Emotions</TabsTrigger>
          <TabsTrigger value="preference">Preferences</TabsTrigger>
          <TabsTrigger value="event">Events</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {/* Memory Timeline */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-xl text-purple-400 font-bold">
                Memory Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              {displayedMemories && displayedMemories.length > 0 ? (
                <div className="space-y-4">
                  {displayedMemories.map((memory: any) => (
                    <div key={memory.id} className="memory-item">
                      <div className="bg-slate-800/50 rounded-xl p-4 border border-purple-500/30">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <Badge className={getTypeColor(memory.type)}>
                              {getTypeIcon(memory.type)}
                              <span className="ml-1 capitalize">{memory.type}</span>
                            </Badge>
                            {memory.importance && (
                              <Badge variant="outline" className="text-yellow-400 border-yellow-500/30">
                                Priority: {memory.importance}/10
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs text-gray-500">
                              {formatDate(memory.createdAt)}
                            </span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteMemory(memory.id)}
                              disabled={deleteMemoryMutation.isPending}
                              className="text-red-400 hover:text-red-300 hover:bg-red-500/20"
                            >
                              {deleteMemoryMutation.isPending ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Trash2 className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        </div>
                        <p className="text-gray-300 text-sm leading-relaxed">{memory.content}</p>
                        {memory.context && Object.keys(memory.context).length > 0 && (
                          <div className="mt-3 text-xs text-gray-500">
                            Context: {JSON.stringify(memory.context)}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Brain className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-400 mb-2">
                    {searchQuery ? "No memories found" : "No memories yet"}
                  </h3>
                  <p className="text-gray-500 mb-6">
                    {searchQuery 
                      ? "Try a different search term or check other categories."
                      : "Memories will appear here as Sinder interacts and learns."
                    }
                  </p>
                  {!searchQuery && (
                    <Button 
                      onClick={() => setShowAddMemory(true)}
                      className="bg-gradient-to-r from-pink-500 to-purple-500"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Add First Memory
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
