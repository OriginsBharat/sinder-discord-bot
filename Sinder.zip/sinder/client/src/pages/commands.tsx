import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Wand2, Trash2, Edit, Loader2, Bot } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import CommandBuilder from "@/components/command-builder";

export default function Commands() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [showBuilder, setShowBuilder] = useState(false);
  const [editingCommand, setEditingCommand] = useState<any>(null);

  const { data: commands = [], isLoading } = useQuery({
    queryKey: ["/api/bots/default-bot/commands"],
  });

  const deleteCommandMutation = useMutation({
    mutationFn: async (commandId: string) => {
      return apiRequest("DELETE", `/api/commands/${commandId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/commands"] });
      toast({
        title: "Command Deleted",
        description: "Command has been successfully removed!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete command. Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleCommandMutation = useMutation({
    mutationFn: async ({ commandId, enabled }: { commandId: string; enabled: boolean }) => {
      return apiRequest("PATCH", `/api/commands/${commandId}`, { enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots/default-bot/commands"] });
    },
  });

  const handleDeleteCommand = (commandId: string) => {
    if (confirm("Are you sure you want to delete this command?")) {
      deleteCommandMutation.mutate(commandId);
    }
  };

  const handleToggleCommand = (commandId: string, enabled: boolean) => {
    toggleCommandMutation.mutate({ commandId, enabled });
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "nsfw": return "bg-red-500/20 text-red-400 border-red-500/30";
      case "emotion": return "bg-pink-500/20 text-pink-400 border-pink-500/30";
      default: return "bg-purple-500/20 text-purple-400 border-purple-500/30";
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="w-8 h-8 animate-spin text-pink-400" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Command Builder
        </h1>
        <Button 
          onClick={() => setShowBuilder(true)}
          className="bg-gradient-to-r from-pink-500 to-purple-500 hover:scale-105 transition-transform"
        >
          <Plus className="mr-2 h-4 w-4" />
          Create Command
        </Button>
      </div>

      {showBuilder && (
        <CommandBuilder 
          onClose={() => {
            setShowBuilder(false);
            setEditingCommand(null);
          }}
          editingCommand={editingCommand}
        />
      )}

      {/* Commands Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.isArray(commands) && commands.map((command: any) => (
          <Card key={command.id} className="glass-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-pink-400 font-bold">
                  /{command.name}
                </CardTitle>
                <div className="flex items-center space-x-2">
                  {command.aiGenerated && (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <Bot className="w-3 h-3 mr-1" />
                      AI
                    </Badge>
                  )}
                  <Badge className={getCategoryColor(command.category)}>
                    {command.category}
                  </Badge>
                </div>
              </div>
              <p className="text-sm text-gray-400">{command.description}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-xs text-gray-500 uppercase tracking-wide">Response</Label>
                <div className="bg-slate-800/50 rounded-lg p-3 mt-1">
                  <p className="text-sm text-gray-300 line-clamp-3">{command.response}</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Switch 
                    checked={command.enabled}
                    onCheckedChange={(enabled) => handleToggleCommand(command.id, enabled)}
                  />
                  <Label className="text-sm text-gray-400">
                    {command.enabled ? "Enabled" : "Disabled"}
                  </Label>
                </div>
                
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setEditingCommand(command);
                      setShowBuilder(true);
                    }}
                    className="bg-purple-500/20 hover:bg-purple-500/30 border-purple-500/40"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteCommand(command.id)}
                    disabled={deleteCommandMutation.isPending}
                    className="bg-red-500/20 hover:bg-red-500/30 border-red-500/40 text-red-400"
                  >
                    {deleteCommandMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {(!Array.isArray(commands) || commands.length === 0) && (
          <div className="col-span-full">
            <Card className="glass-card">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Wand2 className="w-16 h-16 text-gray-500 mb-4" />
                <h3 className="text-xl font-bold text-gray-400 mb-2">No Commands Yet</h3>
                <p className="text-gray-500 text-center mb-6">
                  Create your first command to get started! Use the AI generator for quick setup.
                </p>
                <Button 
                  onClick={() => setShowBuilder(true)}
                  className="bg-gradient-to-r from-pink-500 to-purple-500"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Create First Command
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
