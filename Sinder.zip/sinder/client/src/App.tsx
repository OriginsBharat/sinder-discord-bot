import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Personality from "@/pages/personality";
import Commands from "@/pages/commands";
import Memory from "@/pages/memory";
import Gallery from "@/pages/gallery";
import Servers from "@/pages/servers";
import Settings from "@/pages/settings";
import Sidebar from "@/components/sidebar";
import TopBar from "@/components/topbar";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Sidebar />
      <div className="flex-1 ml-64">
        <TopBar />
        <main className="p-6">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/personality" component={Personality} />
            <Route path="/commands" component={Commands} />
            <Route path="/memory" component={Memory} />
            <Route path="/gallery" component={Gallery} />
            <Route path="/servers" component={Servers} />
            <Route path="/settings" component={Settings} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
