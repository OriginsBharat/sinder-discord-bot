# Railway Deployment Guide for Sinder Discord Bot

## 🚂 Deploy Your Discord Bot on Railway (Free Tier)

Railway provides free hosting with excellent Discord bot support. Follow this guide to deploy Sinder with all features working.

## 📥 Step 1: Export Project from Replit

### Method 1: Download as ZIP (Recommended)
1. **In Replit**: Click the hamburger menu (≡) → **Export** → **Download as ZIP**
2. **Extract** the ZIP file to your local machine
3. **Remove** the `.replit` file (Railway doesn't need it)
4. **You're ready!** Your project folder contains all necessary files

### Method 2: Git Clone (Alternative)
```bash
# If your Replit has Git initialized
git clone https://github.com/yourusername/your-repl-name.git
cd your-repl-name
```

## 🚀 Step 2: Deploy to Railway

### Create Railway Account
1. **Visit**: [railway.app](https://railway.app)
2. **Sign up** with GitHub (recommended)
3. **Verify** your account

### Deploy Your Bot
1. **Click** "New Project" → **Deploy from GitHub repo**
2. **Select** your exported project (upload ZIP or connect GitHub)
3. **Railway auto-detects** Node.js and configures build settings
4. **Deployment starts automatically!**

## 🔧 Step 3: Configure Environment Variables

In Railway dashboard, go to **Variables** tab and add:

### Required Variables
```bash
DISCORD_BOT_TOKEN=your_discord_bot_token_here
GROQ_API_KEY=your_groq_api_key_here
HUGGINGFACE_API_KEY=your_huggingface_token_here
DATABASE_URL=postgresql://user:pass@host:port/db
NODE_ENV=production
```

### Get Your API Keys
1. **Discord Bot Token**: [Discord Developer Portal](https://discord.com/developers/applications)
2. **Groq API Key**: [Groq Console](https://console.groq.com/keys) (Free)
3. **HuggingFace Token**: [HuggingFace Tokens](https://huggingface.co/settings/tokens) (Free)

## 💾 Step 4: Setup PostgreSQL Database

### Option 1: Railway PostgreSQL (Recommended)
1. **In Railway**: Click **Add Service** → **Database** → **PostgreSQL**
2. **Auto-connects**: DATABASE_URL is automatically set
3. **Free tier**: 1GB storage, perfect for Discord bots

### Option 2: External Database
- **Neon**: [neon.tech](https://neon.tech) (Free tier: 3GB)
- **Supabase**: [supabase.com](https://supabase.com) (Free tier: 500MB)
- **ElephantSQL**: [elephantsql.com](https://elephantsql.com) (Free tier: 20MB)

## ⚙️ Step 5: Custom Start Command (If Needed)

Railway auto-detects `npm start` from package.json. If you need custom settings:

1. **Go to** Settings → **Deploy**
2. **Set Start Command**: `npm run build && npm start`
3. **Or Custom Build**: `npm run build`

## 🔒 Step 6: Discord Bot Permissions

### Update Bot Invite URL
Your bot now has comprehensive permissions:
- ✅ **All text permissions** (send, manage, embed, attach files)
- ✅ **Voice permissions** (connect, speak, move members)
- ✅ **Server management** (manage roles, channels, webhooks)
- ❌ **Administrator** (excluded for security)

### Invite Bot to Server
1. **Dashboard** → **Servers** → **Get Invite URL**
2. **Copy the URL** and open in browser
3. **Select your server** and approve permissions
4. **Sinder joins** with full capabilities!

## 🔍 Step 7: Verify Deployment

### Check Logs
1. **Railway Dashboard** → **Deployments** → **View Logs**
2. **Look for**:
   ```
   🚀 Initializing 24/7 Bot Manager...
   ✅ Bot started successfully in 24/7 mode
   🔥 Bot Sinder is ready and running 24/7!
   ```

### Test Bot Commands
In Discord, try:
- `/help` - Shows command help
- `/draw cute catgirl` - Generates AI image
- `/cuddle` - Closeness interaction
- `Hello Sinder` - AI conversation

### Access Dashboard
- **URL**: `https://your-app-name.railway.app`
- **Features**: Bot status, memory viewer, personality editor

## 💰 Railway Free Tier Limits

### Generous Free Limits
- ✅ **$5/month** in credits (usually covers Discord bots)
- ✅ **24/7 uptime** with auto-sleep prevention
- ✅ **Custom domains** available
- ✅ **PostgreSQL database** included
- ✅ **Unlimited deployments**

### Usage Monitoring
- **Track usage** in Railway dashboard
- **Typical Discord bot**: $1-3/month
- **Free credits**: Usually sufficient for small-medium bots

## 🛠️ Troubleshooting

### Bot Won't Start
```bash
# Check environment variables are set
echo $DISCORD_BOT_TOKEN
echo $GROQ_API_KEY
echo $DATABASE_URL
```

### Database Connection Issues
1. **Verify** DATABASE_URL format
2. **Check** PostgreSQL service is running
3. **Run** database push: `npm run db:push`

### API Key Errors
1. **Discord**: Verify bot token and permissions
2. **Groq**: Check API key validity at console.groq.com
3. **HuggingFace**: Verify token at huggingface.co/settings

### Image Generation Not Working
- **Multiple providers** handle failover automatically
- **Pollinations, ImgnAI, Stable Horde** don't require API keys
- **HuggingFace** is backup only

## 🎯 Post-Deployment Checklist

- [ ] Bot appears online in Discord
- [ ] Dashboard accessible at Railway URL
- [ ] `/help` command responds
- [ ] `/draw` generates images
- [ ] AI conversations work
- [ ] Database stores memories
- [ ] 24/7 uptime confirmed
- [ ] All permissions working

## 🔄 Updates and Maintenance

### Deploy Updates
1. **Update code** locally
2. **Push to GitHub** (auto-deploys) OR **Upload new ZIP**
3. **Railway rebuilds** automatically
4. **Zero downtime** deployment

### Monitor Performance
- **Railway Metrics**: CPU, RAM, network usage
- **Bot Logs**: Error tracking and performance
- **Discord Status**: Online presence monitoring

## 📞 Support

### Getting Help
- **Railway Docs**: [docs.railway.app](https://docs.railway.app)
- **Discord Community**: [Railway Discord](https://discord.gg/railway)
- **Bot Issues**: Check console logs in Railway dashboard

### Quick Commands
```bash
# View logs
railway logs

# Connect to database
railway run npm run db:studio

# Deploy from CLI
railway up
```

---

## 🎉 Congratulations!

Your Sinder Discord bot is now running 24/7 on Railway with:
- ✅ **Unlimited NSFW image generation**
- ✅ **Full Discord permissions**
- ✅ **AI conversations with Groq**
- ✅ **PostgreSQL database**
- ✅ **Free hosting**
- ✅ **Auto-scaling**

**Sinder is ready to serve your Discord community!** 🐱💕