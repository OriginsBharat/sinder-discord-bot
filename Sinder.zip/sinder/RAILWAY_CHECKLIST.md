# Railway Deployment Checklist

## Before Deployment
- [ ] All files exported from Replit
- [ ] .replit file removed (not needed for Railway)
- [ ] Environment variables ready

## API Keys Required
- [ ] Discord Bot Token from Discord Developer Portal
- [ ] Groq API Key from console.groq.com (Free)
- [ ] HuggingFace Token from huggingface.co/settings (Free)

## Railway Setup
- [ ] Project deployed to Railway
- [ ] PostgreSQL database added
- [ ] Environment variables configured
- [ ] Build successful
- [ ] Bot appears online in Discord

## Testing
- [ ] /help command works
- [ ] /draw generates images
- [ ] AI conversations respond
- [ ] Dashboard accessible
- [ ] All permissions working

## Bot Permissions
Your bot now has comprehensive Discord permissions:
- ✅ All text permissions (send, manage, embed, attach)
- ✅ Voice permissions (connect, speak, move members)  
- ✅ Server management (roles, channels, webhooks)
- ❌ Administrator (excluded for security)

Invite URL: Get from dashboard → Servers → Invite URL
