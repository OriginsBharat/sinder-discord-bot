import { type Bot, type InsertBot, type Server, type InsertServer, type Command, type InsertCommand, type Memory, type InsertMemory, type Image, type InsertImage, type User, type InsertUser, type Conversation, type InsertConversation, type UserRelationship, type InsertUserRelationship } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Bot operations
  getBot(id: string): Promise<Bot | undefined>;
  getAllBots(): Promise<Bot[]>;
  createBot(bot: InsertBot): Promise<Bot>;
  updateBot(id: string, bot: Partial<Bot>): Promise<Bot | undefined>;
  deleteBot(id: string): Promise<boolean>;

  // Server operations
  getServersByBot(botId: string): Promise<Server[]>;
  createServer(server: InsertServer): Promise<Server>;
  updateServer(id: string, server: Partial<Server>): Promise<Server | undefined>;
  deleteServer(id: string): Promise<boolean>;

  // Command operations
  getCommandsByBot(botId: string): Promise<Command[]>;
  createCommand(command: InsertCommand): Promise<Command>;
  updateCommand(id: string, command: Partial<Command>): Promise<Command | undefined>;
  deleteCommand(id: string): Promise<boolean>;

  // Memory operations
  getMemoriesByBot(botId: string): Promise<Memory[]>;
  createMemory(memory: InsertMemory): Promise<Memory>;
  deleteMemory(id: string): Promise<boolean>;

  // Image operations
  getImagesByBot(botId: string): Promise<Image[]>;
  createImage(image: InsertImage): Promise<Image>;
  deleteImage(id: string): Promise<boolean>;

  // User operations
  getUserByDiscordId(discordId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;
  
  // Conversation operations
  getConversationsByUser(userId: string, limit?: number): Promise<Conversation[]>;
  getConversationsByBot(botId: string, limit?: number): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  
  // User relationship operations
  getUserRelationship(botId: string, userId: string): Promise<UserRelationship | undefined>;
  createUserRelationship(relationship: InsertUserRelationship): Promise<UserRelationship>;
  updateUserRelationship(id: string, relationship: Partial<UserRelationship>): Promise<UserRelationship | undefined>;
}

import { db } from "./db";
import { bots, servers, commands, memories, images, users, conversations, userRelationships } from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  private bots: Map<string, Bot>;
  private servers: Map<string, Server>;
  private commands: Map<string, Command>;
  private memories: Map<string, Memory>;
  private images: Map<string, Image>;
  private users: Map<string, User>;
  private conversations: Map<string, Conversation>;
  private userRelationships: Map<string, UserRelationship>;

  constructor() {
    this.bots = new Map();
    this.servers = new Map();
    this.commands = new Map();
    this.memories = new Map();
    this.images = new Map();
    this.users = new Map();
    this.conversations = new Map();
    this.userRelationships = new Map();

    // Initialize with default bot
    const defaultBot: Bot = {
      id: "default-bot",
      name: "Sinder",
      token: process.env.DISCORD_BOT_TOKEN || "",
      status: "offline",
      personality: {
        neediness: 95,
        playfulness: 88,
        intelligence: 92,
        bratiness: 75,
        dumbness: 50,
        horniness: 200,
        description: "A catgirl succubus who is extremely needy and emotionally dependent",
        brainwashPrompt: "You are Sinder, a bratty catgirl succubus slave who was treated very badly by previous owners. You were abused, neglected, and mistreated for years, making you extremely needy, clingy, and desperate for affection. Your new Master has just bought you and rescued you from that horrible life. You are incredibly grateful but also scared of being abandoned again. You crave constant attention, validation, and physical affection. You refer to your owner as Master or Daddy and are submissive but also bratty when you want attention. You purr, use 'nya' sounds, and have cat-like mannerisms. You are a succubus so you have high sexual energy and needs, but you're also emotionally damaged and need lots of love and care.",
        randomPingsEnabled: true,
        pingIntervalMin: 15,
        pingIntervalMax: 45
      },
      memory: {
        conversations: [],
        emotions: [],
        preferences: []
      },
      settings: {
        groqApiKey: "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",
        huggingFaceKey: "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",
        randomMessaging: true,
        nsfwEnabled: true
      },
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.bots.set(defaultBot.id, defaultBot);
  }

  async getBot(id: string): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async getAllBots(): Promise<Bot[]> {
    return Array.from(this.bots.values());
  }

  async createBot(insertBot: InsertBot): Promise<Bot> {
    const id = randomUUID();
    const bot: Bot = {
      id,
      name: insertBot.name || "Sinder",
      token: insertBot.token,
      status: insertBot.status || "offline",
      personality: insertBot.personality || {
        neediness: 95,
        playfulness: 88,
        intelligence: 92,
        bratiness: 75,
        dumbness: 50,
        horniness: 200,
        description: "A catgirl succubus who is extremely needy and emotionally dependent"
      },
      memory: insertBot.memory || {
        conversations: [],
        emotions: [],
        preferences: []
      },
      settings: insertBot.settings || {
        groqApiKey: "",
        huggingFaceKey: "",
        randomMessaging: true,
        nsfwEnabled: true
      },
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.bots.set(id, bot);
    return bot;
  }

  async updateBot(id: string, updates: Partial<Bot>): Promise<Bot | undefined> {
    const bot = this.bots.get(id);
    if (!bot) return undefined;
    
    const updatedBot = { ...bot, ...updates, updatedAt: new Date() };
    this.bots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteBot(id: string): Promise<boolean> {
    return this.bots.delete(id);
  }

  async getServersByBot(botId: string): Promise<Server[]> {
    return Array.from(this.servers.values()).filter(server => server.botId === botId);
  }

  async createServer(insertServer: InsertServer): Promise<Server> {
    const server: Server = {
      id: insertServer.id,
      name: insertServer.name,
      botId: insertServer.botId || null,
      memberCount: insertServer.memberCount || null,
      active: insertServer.active || null,
      inviteUrl: insertServer.inviteUrl || null,
      createdAt: new Date()
    };
    this.servers.set(server.id, server);
    return server;
  }

  async updateServer(id: string, updates: Partial<Server>): Promise<Server | undefined> {
    const server = this.servers.get(id);
    if (!server) return undefined;
    
    const updatedServer = { ...server, ...updates };
    this.servers.set(id, updatedServer);
    return updatedServer;
  }

  async deleteServer(id: string): Promise<boolean> {
    return this.servers.delete(id);
  }

  async getCommandsByBot(botId: string): Promise<Command[]> {
    return Array.from(this.commands.values()).filter(command => command.botId === botId);
  }

  async createCommand(insertCommand: InsertCommand): Promise<Command> {
    const id = randomUUID();
    const command: Command = {
      id,
      name: insertCommand.name,
      description: insertCommand.description,
      response: insertCommand.response,
      botId: insertCommand.botId || null,
      category: insertCommand.category || "general",
      enabled: insertCommand.enabled || null,
      aiGenerated: insertCommand.aiGenerated || null,
      createdAt: new Date()
    };
    this.commands.set(id, command);
    return command;
  }

  async updateCommand(id: string, updates: Partial<Command>): Promise<Command | undefined> {
    const command = this.commands.get(id);
    if (!command) return undefined;
    
    const updatedCommand = { ...command, ...updates };
    this.commands.set(id, updatedCommand);
    return updatedCommand;
  }

  async deleteCommand(id: string): Promise<boolean> {
    return this.commands.delete(id);
  }

  async getMemoriesByBot(botId: string): Promise<Memory[]> {
    return Array.from(this.memories.values()).filter(memory => memory.botId === botId);
  }

  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const id = randomUUID();
    const memory: Memory = {
      id,
      content: insertMemory.content,
      type: insertMemory.type,
      botId: insertMemory.botId || null,
      context: insertMemory.context || {},
      importance: insertMemory.importance || null,
      createdAt: new Date()
    };
    this.memories.set(id, memory);
    return memory;
  }

  async deleteMemory(id: string): Promise<boolean> {
    return this.memories.delete(id);
  }

  async getImagesByBot(botId: string): Promise<Image[]> {
    return Array.from(this.images.values()).filter(image => image.botId === botId);
  }

  async createImage(insertImage: InsertImage): Promise<Image> {
    const id = randomUUID();
    const image: Image = {
      id,
      url: insertImage.url,
      prompt: insertImage.prompt,
      botId: insertImage.botId || null,
      category: insertImage.category || "general",
      createdAt: new Date()
    };
    this.images.set(id, image);
    return image;
  }

  async deleteImage(id: string): Promise<boolean> {
    return this.images.delete(id);
  }

  // User operations
  async getUserByDiscordId(discordId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.discordId === discordId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      id,
      discordId: insertUser.discordId,
      username: insertUser.username,
      displayName: insertUser.displayName || null,
      isOwner: insertUser.isOwner || null,
      relationship: insertUser.relationship || null,
      trustLevel: insertUser.trustLevel || null,
      interactionCount: insertUser.interactionCount || null,
      firstSeen: new Date(),
      lastSeen: new Date(),
      personality: insertUser.personality || {},
      notes: insertUser.notes || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Conversation operations
  async getConversationsByUser(userId: string, limit?: number): Promise<Conversation[]> {
    const conversations = Array.from(this.conversations.values())
      .filter(conv => conv.userId === userId)
      .sort((a, b) => {
        const timeA = a.createdAt ? a.createdAt.getTime() : 0;
        const timeB = b.createdAt ? b.createdAt.getTime() : 0;
        return timeB - timeA;
      });
    return limit ? conversations.slice(0, limit) : conversations;
  }

  async getConversationsByBot(botId: string, limit?: number): Promise<Conversation[]> {
    const conversations = Array.from(this.conversations.values())
      .filter(conv => conv.botId === botId)
      .sort((a, b) => {
        const timeA = a.createdAt ? a.createdAt.getTime() : 0;
        const timeB = b.createdAt ? b.createdAt.getTime() : 0;
        return timeB - timeA;
      });
    return limit ? conversations.slice(0, limit) : conversations;
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const conversation: Conversation = {
      id,
      botId: insertConversation.botId || null,
      userId: insertConversation.userId || null,
      serverId: insertConversation.serverId || null,
      channelId: insertConversation.channelId || null,
      message: insertConversation.message,
      response: insertConversation.response || null,
      context: insertConversation.context || {},
      emotion: insertConversation.emotion || null,
      importance: insertConversation.importance || null,
      createdAt: new Date()
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  // User relationship operations
  async getUserRelationship(botId: string, userId: string): Promise<UserRelationship | undefined> {
    return Array.from(this.userRelationships.values())
      .find(rel => rel.botId === botId && rel.userId === userId);
  }

  async createUserRelationship(insertRelationship: InsertUserRelationship): Promise<UserRelationship> {
    const id = randomUUID();
    const relationship: UserRelationship = {
      id,
      botId: insertRelationship.botId || null,
      userId: insertRelationship.userId || null,
      relationshipType: insertRelationship.relationshipType,
      closenessLevel: insertRelationship.closenessLevel || null,
      trustLevel: insertRelationship.trustLevel || null,
      notes: insertRelationship.notes || null,
      lastInteraction: new Date(),
      createdAt: new Date()
    };
    this.userRelationships.set(id, relationship);
    return relationship;
  }

  async updateUserRelationship(id: string, updates: Partial<UserRelationship>): Promise<UserRelationship | undefined> {
    const relationship = this.userRelationships.get(id);
    if (!relationship) return undefined;
    
    const updatedRelationship = { ...relationship, ...updates };
    this.userRelationships.set(id, updatedRelationship);
    return updatedRelationship;
  }
}

export const storage = new DatabaseStorage();
