import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { discordService } from "./services/discord";
import { aiService } from "./services/ai";
import { memoryService } from "./services/memory";
import { imageGenerationService } from "./services/image-generation";
import { bot24x7Manager } from "./start-24-7";
import { insertBotSchema, insertCommandSchema, insertMemorySchema, insertImageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Bot routes
  app.get("/api/bots", async (req, res) => {
    try {
      const bots = await storage.getAllBots();
      res.json(bots);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bots" });
    }
  });

  app.get("/api/bots/:id", async (req, res) => {
    try {
      const bot = await storage.getBot(req.params.id);
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      res.json(bot);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bot" });
    }
  });

  app.post("/api/bots", async (req, res) => {
    try {
      const validatedData = insertBotSchema.parse(req.body);
      const bot = await storage.createBot(validatedData);
      res.status(201).json(bot);
    } catch (error) {
      res.status(400).json({ error: "Invalid bot data" });
    }
  });

  app.patch("/api/bots/:id", async (req, res) => {
    try {
      const bot = await storage.updateBot(req.params.id, req.body);
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }
      res.json(bot);
    } catch (error) {
      res.status(500).json({ error: "Failed to update bot" });
    }
  });

  // Discord bot control
  app.post("/api/bots/:id/start", async (req, res) => {
    try {
      const success = await discordService.startBot(req.params.id);
      if (success) {
        res.json({ message: "Bot started successfully" });
      } else {
        res.status(500).json({ error: "Failed to start bot" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to start bot" });
    }
  });

  app.post("/api/bots/:id/stop", async (req, res) => {
    try {
      const success = await discordService.stopBot(req.params.id);
      if (success) {
        res.json({ message: "Bot stopped successfully" });
      } else {
        res.status(500).json({ error: "Failed to stop bot" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to stop bot" });
    }
  });

  app.get("/api/bots/:id/status", async (req, res) => {
    try {
      const status = await discordService.getBotStatus(req.params.id);
      const serverCount = await discordService.getServerCount(req.params.id);
      res.json({ status, serverCount });
    } catch (error) {
      res.status(500).json({ error: "Failed to get bot status" });
    }
  });

  app.get("/api/bots/:id/invite-url", async (req, res) => {
    try {
      // Use the correct Discord client ID for Sinder bot
      const clientId = "1393230039587360798";
      
      // Comprehensive Discord permissions (everything except Administrator)
      // Using proper bitwise permission calculation
      const permissions = {
        VIEW_CHANNELS: 1024,
        SEND_MESSAGES: 2048,
        SEND_TTS_MESSAGES: 4096,
        MANAGE_MESSAGES: 8192,
        EMBED_LINKS: 16384,
        ATTACH_FILES: 32768,
        READ_MESSAGE_HISTORY: 65536,
        MENTION_EVERYONE: 131072,
        USE_EXTERNAL_EMOJIS: 262144,
        CONNECT: 1048576,
        SPEAK: 2097152,
        MUTE_MEMBERS: 8388608,
        DEAFEN_MEMBERS: 16777216,
        MOVE_MEMBERS: 33554432,
        USE_VAD: 67108864,
        CHANGE_NICKNAME: 1073741824,
        MANAGE_NICKNAMES: 2147483648,
        MANAGE_ROLES: 4294967296,
        MANAGE_WEBHOOKS: 137438953472,
        USE_APPLICATION_COMMANDS: 2199023255552,
        MANAGE_THREADS: 4398046511104,
        CREATE_PUBLIC_THREADS: 8796093022208,
        CREATE_PRIVATE_THREADS: 17592186044416,
        USE_EXTERNAL_STICKERS: 35184372088832,
        SEND_MESSAGES_IN_THREADS: 70368744177664,
        START_EMBEDDED_ACTIVITIES: 140737488355328,
        MODERATE_MEMBERS: 1099511627776
      };
      
      // Calculate total permissions (sum all values except Administrator which is 8)
      const totalPermissions = Object.values(permissions).reduce((sum, perm) => sum + perm, 0).toString();

      const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=${totalPermissions}&scope=bot+applications.commands`;
      
      res.json({ 
        url: inviteUrl,
        clientId: clientId,
        permissions: totalPermissions,
        description: "All permissions except Administrator - can send messages, manage channels, use voice, manage roles, etc."
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate invite URL" });
    }
  });

  // AI Model Statistics
  app.get("/api/ai/models/stats", async (req, res) => {
    try {
      const stats = aiService.getModelStats();
      res.json({ 
        success: true, 
        models: stats,
        totalModels: Object.keys(stats).length,
        availableModels: ["Groq (Primary)", "Hermes 3 (Free)", "Dolphin (Free)", "Llama Lexi Uncensored (Free)", "Together Hermes (Free)", "OpenRouter Hermes (Free)"]
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ success: false, error: errorMessage });
    }
  });

  // Test API connections
  app.post("/api/test/groq", async (req, res) => {
    try {
      const response = await aiService.generateResponse("Hello", {
        neediness: 50,
        playfulness: 50,
        intelligence: 50,
        bratiness: 50,
        dumbness: 50,
        horniness: 50,
        description: "Test personality"
      }, []);
      res.json({ success: true, response: response.content });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ success: false, error: errorMessage });
    }
  });

  app.post("/api/test/huggingface", async (req, res) => {
    try {
      const imageUrl = await aiService.generateImage("test image");
      res.json({ success: true, imageUrl });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ success: false, error: errorMessage });
    }
  });

  app.post("/api/test/discord", async (req, res) => {
    try {
      const { message } = req.body;
      const response = await discordService.handleMessage('default-bot', message, 'test-user');
      res.json({ success: true, response });
    } catch (error) {
      console.error('Discord test error:', error);
      res.status(500).json({ success: false, error: 'Failed to handle message' });
    }
  });

  // Create predefined closeness commands
  app.post("/api/bots/:id/commands/closeness", async (req, res) => {
    try {
      const botId = req.params.id;
      const closenessCommands = [
        {
          botId,
          name: "cuddle",
          description: "Cuddle with Sinder to increase closeness",
          response: "*purrs loudly and nuzzles against you* Nya~ Master's cuddles are the best! I feel so warm and loved! 💕 *wraps tail around you*",
          category: "emotion",
          enabled: true,
          aiGenerated: false
        },
        {
          botId,
          name: "kiss",
          description: "Give Sinder a kiss for maximum closeness",
          response: "*blushes deeply and purrs* Nya~ Master's kisses make my heart race! *nuzzles cheek* I love you so much! 😽💕",
          category: "emotion",
          enabled: true,
          aiGenerated: false
        },
        {
          botId,
          name: "headpat",
          description: "Give Sinder headpats to build affection",
          response: "*melts under your touch and purrs loudly* Nya~ Headpats are my weakness! More please, Master! *pushes head into your hand* 🥰",
          category: "emotion",
          enabled: true,
          aiGenerated: false
        },
        {
          botId,
          name: "praise",
          description: "Praise Sinder for being a good girl",
          response: "*eyes sparkle with joy* Nya~ Really?! I'm such a good girl?! *happy bouncing* Master's praise makes me so happy! I'll be even better for you! ✨💕",
          category: "emotion",
          enabled: true,
          aiGenerated: false
        }
      ];

      const createdCommands = [];
      for (const command of closenessCommands) {
        const created = await storage.createCommand(command);
        createdCommands.push(created);
      }

      res.json({ success: true, commands: createdCommands });
    } catch (error) {
      res.status(500).json({ success: false, error: "Failed to create closeness commands" });
    }
  });

  // Generate Discord invite link
  app.get("/api/bots/:id/invite", async (req, res) => {
    try {
      const bot = await storage.getBot(req.params.id);
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }

      // Extract client ID from Discord bot token (decode base64 first part)
      const tokenParts = bot.token.split('.');
      if (tokenParts.length < 3) {
        return res.status(400).json({ error: "Invalid bot token format" });
      }

      // Decode the base64 encoded client ID  
      let clientId;
      try {
        const decoded = Buffer.from(tokenParts[0], 'base64').toString('utf-8');
        // Check if decoded result is a valid snowflake (numeric string)
        if (decoded.match(/^\d+$/)) {
          clientId = decoded;
        } else {
          // If not numeric, use the original token part
          clientId = tokenParts[0];
        }
      } catch (decodeError) {
        // If base64 decoding fails, the first part might already be the client ID
        clientId = tokenParts[0];
      }

      if (!clientId) {
        return res.status(400).json({ error: "Could not extract client ID from token" });
      }

      // Generate invite URL with necessary permissions
      const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=537259072&scope=bot`;
      
      res.json({ 
        inviteUrl,
        botName: bot.name
      });
    } catch (error) {
      console.error('Error generating invite link:', error);
      res.status(500).json({ error: "Failed to generate invite link" });
    }
  });

  // Command routes
  app.get("/api/bots/:botId/commands", async (req, res) => {
    try {
      const commands = await storage.getCommandsByBot(req.params.botId);
      res.json(commands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch commands" });
    }
  });

  app.post("/api/bots/:botId/commands", async (req, res) => {
    try {
      const validatedData = insertCommandSchema.parse({
        ...req.body,
        botId: req.params.botId
      });
      const command = await storage.createCommand(validatedData);
      res.status(201).json(command);
    } catch (error) {
      res.status(400).json({ error: "Invalid command data" });
    }
  });

  app.patch("/api/commands/:id", async (req, res) => {
    try {
      const command = await storage.updateCommand(req.params.id, req.body);
      if (!command) {
        return res.status(404).json({ error: "Command not found" });
      }
      res.json(command);
    } catch (error) {
      res.status(500).json({ error: "Failed to update command" });
    }
  });

  app.delete("/api/commands/:id", async (req, res) => {
    try {
      const success = await storage.deleteCommand(req.params.id);
      if (success) {
        res.json({ message: "Command deleted successfully" });
      } else {
        res.status(404).json({ error: "Command not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete command" });
    }
  });

  // AI command generation
  app.post("/api/bots/:botId/commands/generate", async (req, res) => {
    try {
      const { description } = req.body;
      const bot = await storage.getBot(req.params.botId);
      
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }

      const generatedCommand = await aiService.generateCommand(description);

      if (!generatedCommand) {
        return res.status(500).json({ error: "Failed to generate command" });
      }

      res.json(generatedCommand);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate command" });
    }
  });

  // AI personality generation
  app.post("/api/bots/:botId/personality/generate", async (req, res) => {
    try {
      const { description } = req.body;
      const bot = await storage.getBot(req.params.botId);
      
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }

      const generatedPersonality = await aiService.generatePersonality(description);

      if (!generatedPersonality) {
        return res.status(500).json({ error: "Failed to generate personality" });
      }

      res.json(generatedPersonality);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate personality" });
    }
  });

  // Memory routes
  app.get("/api/bots/:botId/memories", async (req, res) => {
    try {
      const { type, limit } = req.query;
      let memories;
      
      if (type) {
        memories = await memoryService.getMemoriesByType(req.params.botId, type as string);
      } else {
        memories = await memoryService.getRecentMemories(
          req.params.botId, 
          limit ? parseInt(limit as string) : 50
        );
      }
      
      res.json(memories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch memories" });
    }
  });

  app.post("/api/bots/:botId/memories", async (req, res) => {
    try {
      const validatedData = insertMemorySchema.parse({
        ...req.body,
        botId: req.params.botId
      });
      await memoryService.addMemory(req.params.botId, validatedData);
      res.status(201).json({ message: "Memory added successfully" });
    } catch (error) {
      res.status(400).json({ error: "Invalid memory data" });
    }
  });

  app.get("/api/bots/:botId/memories/stats", async (req, res) => {
    try {
      const stats = await memoryService.getMemoryStats(req.params.botId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch memory stats" });
    }
  });

  app.get("/api/bots/:botId/memories/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ error: "Query parameter required" });
      }
      
      const memories = await memoryService.searchMemories(req.params.botId, q as string);
      res.json(memories);
    } catch (error) {
      res.status(500).json({ error: "Failed to search memories" });
    }
  });

  app.delete("/api/memories/:id", async (req, res) => {
    try {
      const success = await storage.deleteMemory(req.params.id);
      if (success) {
        res.json({ message: "Memory deleted successfully" });
      } else {
        res.status(404).json({ error: "Memory not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete memory" });
    }
  });

  // Image generation and gallery
  app.post("/api/bots/:botId/images/generate", async (req, res) => {
    try {
      const { prompt } = req.body;
      const bot = await storage.getBot(req.params.botId);
      
      if (!bot) {
        return res.status(404).json({ error: "Bot not found" });
      }

      const imageUrl = await aiService.generateImage(prompt);
      
      if (!imageUrl) {
        return res.status(500).json({ error: "Failed to generate image" });
      }

      const image = await storage.createImage({
        botId: req.params.botId,
        prompt,
        url: imageUrl,
        category: req.body.category || "general"
      });

      res.json(image);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate image" });
    }
  });

  app.get("/api/bots/:botId/images", async (req, res) => {
    try {
      const images = await storage.getImagesByBot(req.params.botId);
      res.json(images);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  app.delete("/api/images/:id", async (req, res) => {
    try {
      const success = await storage.deleteImage(req.params.id);
      if (success) {
        res.json({ message: "Image deleted successfully" });
      } else {
        res.status(404).json({ error: "Image not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete image" });
    }
  });

  // Server management
  app.get("/api/bots/:botId/servers", async (req, res) => {
    try {
      const servers = await storage.getServersByBot(req.params.botId);
      res.json(servers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch servers" });
    }
  });

  // 24/7 Bot Monitoring and Management API
  app.get("/api/system/status", async (req, res) => {
    try {
      const systemStatus = await bot24x7Manager.getSystemStatus();
      res.json(systemStatus);
    } catch (error) {
      res.status(500).json({ error: "Failed to get system status" });
    }
  });

  app.get("/api/bots/:botId/stats", async (req, res) => {
    try {
      const stats = await discordService.getBotStats(req.params.botId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to get bot statistics" });
    }
  });

  app.get("/api/system/uptime", async (req, res) => {
    try {
      const systemUptime = process.uptime();
      const botStats = await discordService.getBotStats('default-bot');
      
      res.json({
        system: {
          uptime: systemUptime,
          uptimeFormatted: formatUptime(systemUptime),
          memory: process.memoryUsage(),
          platform: process.platform,
          nodeVersion: process.version
        },
        bot: {
          status: botStats.status,
          uptime: botStats.uptime,
          servers: botStats.servers,
          keepAlive: botStats.keepAlive
        },
        keepAlive: {
          mode: "24/7",
          pingInterval: "5 minutes", 
          autoRestart: true,
          monitoring: "active"
        }
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get uptime information" });
    }
  });

  // Keep-alive ping endpoint (for external monitoring)
  app.get("/ping", (req, res) => {
    res.json({ 
      ping: "pong", 
      timestamp: Date.now(),
      uptime: process.uptime(),
      status: "online",
      bot: "Sinder 24/7"
    });
  });

  app.get("/health", async (req, res) => {
    try {
      const botStats = await discordService.getBotStats('default-bot');
      const isHealthy = botStats.status === 'online' && botStats.keepAlive;
      
      res.status(isHealthy ? 200 : 503).json({
        status: isHealthy ? "healthy" : "unhealthy",
        bot: botStats,
        system: {
          uptime: process.uptime(),
          memory: process.memoryUsage()
        },
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(503).json({ 
        status: "unhealthy", 
        error: "Health check failed",
        timestamp: new Date().toISOString()
      });
    }
  });

  // Utility function for formatting uptime
  function formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  }

  // AI Image Generation Routes
  app.get("/api/ai/image/test", async (req, res) => {
    try {
      console.log("🧪 Testing Image Generation services...");
      
      const testResults = {
        huggingface: { status: 'testing', response: null, error: null }
      };

      try {
        console.log("🧪 Testing HuggingFace Image Generation API...");
        const imageResult = await imageGenerationService.generateImage("cute anime cat girl", true);
        if (imageResult.success) {
          testResults.huggingface = { 
            status: 'success', 
            response: `Image generated successfully with ${imageResult.modelUsed}`, 
            modelUsed: imageResult.modelUsed,
            error: null 
          };
          console.log("✅ HuggingFace image generation test successful");
        } else {
          testResults.huggingface = { 
            status: 'error', 
            response: null, 
            error: imageResult.error 
          };
        }
      } catch (error) {
        console.error("❌ HuggingFace image generation test failed:", error);
        testResults.huggingface = { status: 'error', response: null, error: error.message };
      }

      res.json({
        success: true,
        timestamp: new Date().toISOString(),
        results: testResults
      });
    } catch (error) {
      console.error("❌ Image generation test endpoint error:", error);
      res.status(500).json({ 
        success: false, 
        error: "Image generation test failed",
        timestamp: new Date().toISOString()
      });
    }
  });

  // AI Image Model Statistics
  app.get("/api/ai/image/models/stats", async (req, res) => {
    try {
      const modelStats = imageGenerationService.getModelStats();
      const availableModels = imageGenerationService.getAvailableModels();
      
      res.json({
        success: true,
        totalModels: modelStats.totalModels,
        availableModels: modelStats.availableModels,
        currentModel: modelStats.currentModel,
        models: availableModels.map(model => ({
          name: model.name,
          uncensored: model.uncensored,
          free: model.free,
          description: model.description,
          status: 'ready'
        }))
      });
    } catch (error) {
      res.status(500).json({ success: false, error: "Failed to get image model stats" });
    }
  });

  // Generate Image API
  app.post("/api/ai/image/generate", async (req, res) => {
    try {
      const { prompt, nsfw = true } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ success: false, error: "Prompt is required" });
      }

      console.log(`🎨 API request to generate image: "${prompt}"`);
      const result = await imageGenerationService.generateImage(prompt, nsfw);
      
      if (result.success) {
        res.json({
          success: true,
          imageUrl: result.imageUrl,
          modelUsed: result.modelUsed,
          prompt
        });
      } else {
        res.status(500).json({
          success: false,
          error: result.error
        });
      }
    } catch (error) {
      console.error("❌ Image generation API error:", error);
      res.status(500).json({ 
        success: false, 
        error: "Failed to generate image" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
