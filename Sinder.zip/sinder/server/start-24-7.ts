/**
 * 24/7 Bot Startup Script
 * Automatically starts the Discord bot with keep-alive functionality
 * No manual on/off controls - runs continuously
 */

import { discordService } from './services/discord';
import { storage } from './storage';

// Keep-alive system will be started separately via Python

class Bot24x7Manager {
  private static instance: Bot24x7Manager;
  private isRunning: boolean = false;

  public static getInstance(): Bot24x7Manager {
    if (!Bot24x7Manager.instance) {
      Bot24x7Manager.instance = new Bot24x7Manager();
    }
    return Bot24x7Manager.instance;
  }

  async initialize(): Promise<void> {
    console.log('🚀 Initializing 24/7 Bot Manager...');
    
    try {
      // Enable 24/7 mode (no on/off button)
      discordService.setKeepAliveMode(true);
      
      // Start keep-alive server for external monitoring
      this.startKeepAliveServices();
      
      // Auto-start the default bot
      await this.autoStartDefaultBot();
      
      // Set up process monitors
      this.setupProcessMonitors();
      
      this.isRunning = true;
      console.log('✅ 24/7 Bot Manager initialized successfully!');
      
    } catch (error) {
      console.error('❌ Failed to initialize 24/7 Bot Manager:', error);
      process.exit(1);
    }
  }

  private startKeepAliveServices(): void {
    try {
      // Start Python keep-alive server in background (if available)
      import('child_process').then(({ spawn }) => {
        try {
          const pythonProcess = spawn('python', ['keep_alive.py'], {
            stdio: 'pipe',
            detached: false
          });
          
          // Handle process errors
          pythonProcess.on('error', (error) => {
            console.log('⚠️ Python keep-alive server not available, using JavaScript monitoring only');
          });
          
          pythonProcess.on('spawn', () => {
            console.log('🔄 Python keep-alive server started on port 8080');
          });
          
          // Don't unref - keep process alive with main application
          
        } catch (error) {
          console.log('⚠️ Python keep-alive not available, using JavaScript monitoring only');
        }
      }).catch(() => {
        console.log('⚠️ Child process not available, using JavaScript monitoring only');
      });
      
    } catch (error) {
      console.error('⚠️ Keep-alive services not available:', error);
      // Continue without keep-alive - still functional
    }
  }

  private async autoStartDefaultBot(): Promise<void> {
    try {
      const bot = await storage.getBot('default-bot');
      if (!bot) {
        console.log('❌ Default bot not found');
        return;
      }

      if (!bot.token || bot.token.length < 10) {
        console.log('⚠️ Bot token not configured - waiting for setup');
        console.log('💡 Set your DISCORD_BOT_TOKEN environment variable to auto-start');
        return;
      }

      console.log(`🔥 Auto-starting bot: ${bot.name}`);
      const success = await discordService.startBot('default-bot');
      
      if (success) {
        console.log('✅ Bot started successfully in 24/7 mode');
        
        // Log successful startup
        const stats = await discordService.getBotStats('default-bot');
        console.log('📊 Bot Statistics:', {
          name: stats.botName,
          status: stats.status,
          keepAlive: stats.keepAlive,
          uptime: `${Math.floor(stats.uptime / 60)} minutes`
        });
      } else {
        console.log('❌ Failed to start bot automatically');
        console.log('🔄 Will retry in 30 seconds...');
        
        // Retry connection after 30 seconds
        setTimeout(() => {
          this.autoStartDefaultBot();
        }, 30000);
      }
    } catch (error) {
      console.error('💥 Error auto-starting bot:', error);
      console.log('🔄 Will retry in 30 seconds...');
      setTimeout(() => {
        this.autoStartDefaultBot();
      }, 30000);
    }
  }

  private setupProcessMonitors(): void {
    // Handle graceful shutdown
    process.on('SIGINT', async () => {
      console.log('🛑 Received SIGINT - attempting graceful shutdown...');
      await this.shutdown();
      process.exit(0);
    });

    process.on('SIGTERM', async () => {
      console.log('🛑 Received SIGTERM - attempting graceful shutdown...');
      await this.shutdown();
      process.exit(0);
    });

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('💥 Uncaught Exception:', error);
      // Don't exit - try to keep the bot running
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
      // Don't exit - try to keep the bot running
    });

    console.log('🛡️ Process monitors configured for 24/7 operation');
  }

  async getSystemStatus(): Promise<any> {
    const stats = await discordService.getBotStats('default-bot');
    const systemUptime = process.uptime();
    
    return {
      system: {
        uptime: systemUptime,
        uptimeFormatted: this.formatUptime(systemUptime),
        memory: process.memoryUsage(),
        pid: process.pid,
        platform: process.platform,
        nodeVersion: process.version
      },
      bot: stats,
      keepAlive: {
        enabled: this.isRunning,
        mode: '24/7',
        monitoring: 'active'
      },
      timestamp: new Date().toISOString()
    };
  }

  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  }

  private async shutdown(): Promise<void> {
    console.log('🔄 Shutting down 24/7 Bot Manager...');
    
    try {
      await discordService.stopBot('default-bot');
      this.isRunning = false;
      console.log('✅ Shutdown complete');
    } catch (error) {
      console.error('❌ Error during shutdown:', error);
    }
  }
}

// Export singleton instance
export const bot24x7Manager = Bot24x7Manager.getInstance();

// Auto-initialize if running directly (ES module equivalent)
if (import.meta.url === `file://${process.argv[1]}`) {
  bot24x7Manager.initialize().catch(console.error);
}