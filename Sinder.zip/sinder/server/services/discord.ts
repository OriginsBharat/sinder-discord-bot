import { Client, GatewayIntentBits, ActivityType } from 'discord.js';
import { storage } from '../storage';
import { aiService } from './ai';
import { memoryService } from './memory';
import { imageGenerationService } from './image-generation';
import * as fs from 'fs';
import * as path from 'path';

class DiscordService {
  private clients: Map<string, Client> = new Map();
  private uptimeTimers: Map<string, NodeJS.Timeout> = new Map();
  private isKeepAliveEnabled: boolean = true;

  async startBot(botId: string): Promise<boolean> {
    try {
      const bot = await storage.getBot(botId);
      if (!bot || !bot.token) {
        throw new Error('Bot not found or token missing');
      }

      if (this.clients.has(botId)) {
        await this.stopBot(botId);
      }

      const client = new Client({
        intents: [
          GatewayIntentBits.Guilds,
          GatewayIntentBits.GuildMessages,
          GatewayIntentBits.MessageContent,
          GatewayIntentBits.DirectMessages
        ]
      });

      client.once('ready', async () => {
        console.log(`🔥 Bot ${bot.name} is ready and running 24/7!`);
        await storage.updateBot(botId, { status: 'online' });
        
        // Set bot activity with uptime indicator
        client.user?.setActivity(`24/7 Online | ${bot.name} Never Sleeps`, { 
          type: ActivityType.Watching 
        });

        // Start 24/7 uptime monitoring
        this.startUptimeMonitoring(botId, client);

        // Start random ping messaging if enabled
        if ((bot.personality as any)?.randomPingsEnabled) {
          this.startRandomPingMessaging(botId, client);
        }

        // Log bot startup to memory
        await memoryService.addMemory(botId, {
          type: 'system',
          content: `Bot ${bot.name} started successfully with 24/7 uptime enabled`,
          context: { timestamp: new Date().toISOString(), status: 'online' }
        });
      });

      client.on('messageCreate', async (message) => {
        if (message.author.bot) return;

        const response = await this.handleMessage(message.author.id, botId, message.content);
        if (response) {
          try {
            // Handle different response types
            if (typeof response === 'object' && response.attachment) {
              // Send as Discord file attachment
              console.log(`📤 Sending Discord attachment: ${response.attachment.name}, buffer: ${response.attachment.buffer.length} bytes`);
              
              // Log first few bytes of buffer to check if it's valid image data
              const bufferPreview = Array.from(response.attachment.buffer.slice(0, 8))
                .map(b => b.toString(16).padStart(2, '0'))
                .join(' ');
              console.log(`🔍 Buffer preview (first 8 bytes): ${bufferPreview}`);
              
              await message.reply({
                content: response.content,
                files: [{
                  attachment: response.attachment.buffer,
                  name: response.attachment.name,
                  description: response.attachment.description
                }]
              });
              
              // Store conversation in memory
              await memoryService.addMemory(botId, {
                type: 'conversation',
                content: `User: ${message.content}\nBot: [Generated image: ${response.attachment.description}]`,
                context: { userId: message.author.id, channelId: message.channel.id, type: 'image_generation' }
              });
            } else {
              // Send as regular text message
              const responseText = typeof response === 'string' ? response : response.content;
              await message.reply(responseText);
              
              // Store conversation in memory
              await memoryService.addMemory(botId, {
                type: 'conversation',
                content: `User: ${message.content}\nBot: ${responseText}`,
                context: { userId: message.author.id, channelId: message.channel.id }
              });
            }
          } catch (error) {
            console.error('💥 Error sending Discord message:', error);
            // Fallback to simple text response
            await message.reply("Nya~ I had trouble sending that, Master... *technical difficulties* 😿");
          }
        }
      });

      await client.login(bot.token);
      this.clients.set(botId, client);
      return true;
    } catch (error) {
      console.error('Error starting bot:', error);
      await storage.updateBot(botId, { status: 'error' });
      return false;
    }
  }

  async stopBot(botId: string): Promise<boolean> {
    try {
      const client = this.clients.get(botId);
      if (client) {
        client.destroy();
        this.clients.delete(botId);
      }
      
      // Clear uptime monitoring
      const timer = this.uptimeTimers.get(botId);
      if (timer) {
        clearTimeout(timer);
        this.uptimeTimers.delete(botId);
      }
      
      await storage.updateBot(botId, { status: 'offline' });
      console.log(`🛑 Bot ${botId} stopped and uptime monitoring disabled`);
      return true;
    } catch (error) {
      console.error('Error stopping bot:', error);
      return false;
    }
  }

  async handleMessage(botId: string, content: string, userId: string): Promise<string | { content: string; attachment: { buffer: Buffer; name: string; description: string } } | null> {
    try {
      const bot = await storage.getBot(botId);
      if (!bot) return null;

      // Handle built-in /help command
      if (content.toLowerCase().startsWith('/help')) {
        const helpMessage = `**🐱 Sinder's Commands Help** 💕

**💝 Closeness Commands:**
• \`/cuddle\` - Cuddle with me for comfort and warmth
• \`/kiss\` - Give me sweet kisses  
• \`/headpat\` - Pat my head (I love this!)
• \`/praise\` - Tell me I'm a good girl

**🎨 Utility Commands:**
• \`/draw [prompt]\` - I'll create artwork for you
• \`/help\` - Show this help menu

**✨ Usage Examples:**
• \`/draw cute catgirl in garden\`
• \`/cuddle\` 
• \`/headpat\`

Nya~ Use any command by typing it in chat! I'm always here for you Master! 🐱💕`;
        
        await memoryService.addMemory(botId, {
          type: 'event',
          content: `User ${userId} requested help menu`,
          context: { userId, command: 'help' }
        });
        
        return helpMessage;
      }

      // Handle built-in /draw command
      if (content.toLowerCase().startsWith('/draw ')) {
        const prompt = content.slice(6).trim();
        if (!prompt) {
          return "Nya~ What do you want me to draw, Master? Give me a prompt after /draw! *tilts head*";
        }
        
        try {
          console.log(`🎨 Processing /draw command with prompt: "${prompt}"`);
          const imageResult = await imageGenerationService.generateImage(prompt, true);
          
          if (!imageResult.success) {
            console.error('🚫 Image generation failed:', imageResult.error);
            return `Nya~ Sorry Master, I'm having trouble with my art supplies right now... ${imageResult.error} *sad meow* 😿`;
          }
          
          console.log(`✅ Image generated successfully with ${imageResult.modelUsed}`);
          
          // Store image in database
          await storage.createImage({
            botId,
            prompt,
            url: imageResult.imageUrl!,
            category: 'general'
          });
          
          await memoryService.addMemory(botId, {
            type: 'event',
            content: `Generated uncensored image for prompt: ${prompt} using ${imageResult.modelUsed}`,
            context: { userId, command: 'draw', model: imageResult.modelUsed }
          });
          
          // Direct image URL approach - skip base64 conversion for Discord
          try {
            // Get the original image URL from Pollinations directly
            const directImageResponse = await fetch(imageResult.imageUrl!);
            if (directImageResponse.ok) {
              const directImageBuffer = Buffer.from(await directImageResponse.arrayBuffer());
              
              console.log(`📤 Using direct image buffer from API: ${directImageBuffer.length} bytes`);
              
              // Save test file to verify
              const fs = require('fs');
              const testPath = `/tmp/direct_test_${Date.now()}.jpg`;
              fs.writeFileSync(testPath, directImageBuffer);
              console.log(`✅ Direct image saved to ${testPath} for verification`);
              
              return {
                content: `Nya~ I drew something special and uncensored for you, Master! *purrs proudly* 🎨\n✨ Generated with: **${imageResult.modelUsed}** (free & uncensored)\n🔍 Direct buffer: ${directImageBuffer.length} bytes`,
                attachment: {
                  buffer: directImageBuffer,
                  name: `sinder_uncensored_art_${Date.now()}.jpg`,
                  description: `Uncensored AI artwork: ${prompt}`
                }
              };
            }
          } catch (directError) {
            console.error('❌ Direct image fetch failed, falling back to base64:', directError);
          }
          
          // Fallback: Convert base64 to buffer for Discord attachment
          const base64Data = imageResult.imageUrl!.split(',')[1];
          const imageBuffer = Buffer.from(base64Data, 'base64');
          
          // Detect image format from data URL
          const mimeType = imageResult.imageUrl!.split(';')[0].split(':')[1];
          let fileExtension = 'jpg';
          if (mimeType.includes('png')) {
            fileExtension = 'png';
          } else if (mimeType.includes('webp')) {
            fileExtension = 'webp';
          }
          
          console.log(`📤 Sending uncensored image as Discord attachment, buffer size: ${imageBuffer.length} bytes, format: ${mimeType}`);
          
          // Validate buffer size
          if (imageBuffer.length < 100) {
            console.error('❌ Image buffer too small, likely corrupt data');
            return "Nya~ Sorry Master, the image didn't generate properly... *sad meow* 😿";
          }
          
          // Return special format for Discord attachment handling
          return {
            content: `Nya~ I drew something special and uncensored for you, Master! *purrs proudly* 🎨\n✨ Generated with: **${imageResult.modelUsed}** (free & uncensored)\n🔍 Debug: ${imageBuffer.length} bytes, format: ${mimeType}`,
            attachment: {
              buffer: imageBuffer,
              name: `sinder_uncensored_art_${Date.now()}.${fileExtension}`,
              description: `Uncensored AI artwork: ${prompt}`
            }
          };
        } catch (error) {
          console.error('🚫 Image generation error:', error);
          return "Nya~ Sorry Master, I'm having trouble with my uncensored art supplies right now... *sad meow* 😿";
        }
      }

      // Handle closeness commands
      if (content.toLowerCase().startsWith('/cuddle')) {
        await memoryService.addMemory(botId, {
          type: 'emotion',
          content: `User ${userId} cuddled with Sinder`,
          context: { userId, action: 'cuddle', closeness: '+high' }
        });
        return "*purrs loudly and nuzzles against you* Nya~ Master's cuddles are the best! I feel so warm and loved! 💕 *wraps tail around you*";
      }

      if (content.toLowerCase().startsWith('/kiss')) {
        await memoryService.addMemory(botId, {
          type: 'emotion',
          content: `User ${userId} kissed Sinder`,
          context: { userId, action: 'kiss', closeness: '+very_high' }
        });
        return "*blushes deeply and purrs* Nya~ Master's kisses make my heart race! *nuzzles cheek* I love you so much! 😽💕";
      }

      if (content.toLowerCase().startsWith('/headpat')) {
        await memoryService.addMemory(botId, {
          type: 'emotion',
          content: `User ${userId} gave Sinder headpats`,
          context: { userId, action: 'headpat', closeness: '+medium' }
        });
        return "*melts under your touch and purrs loudly* Nya~ Headpats are my weakness! More please, Master! *pushes head into your hand* 🥰";
      }

      if (content.toLowerCase().startsWith('/praise')) {
        await memoryService.addMemory(botId, {
          type: 'emotion',
          content: `User ${userId} praised Sinder`,
          context: { userId, action: 'praise', closeness: '+high' }
        });
        return "*eyes sparkle with joy* Nya~ Really?! I'm such a good girl?! *happy bouncing* Master's praise makes me so happy! I'll be even better for you! ✨💕";
      }

      // Check for custom commands
      const commands = await storage.getCommandsByBot(botId);
      const command = commands.find(cmd => 
        content.toLowerCase().startsWith(`/${cmd.name.toLowerCase()}`)
      );

      if (command && command.enabled) {
        return this.processCommandResponse(command.response, bot);
      }

      // Use AI for general conversation
      const memories = await storage.getMemoriesByBot(botId);
      const context = this.buildContext(memories, bot.personality);
      
      const aiResponse = await aiService.generateResponse(content, bot.personality as any, memories);
      return aiResponse.content;
    } catch (error) {
      console.error('Error handling message:', error);
      return "Sorry, I'm having trouble responding right now... *sad cat noises* 🥺";
    }
  }

  private processCommandResponse(response: string, bot: any): string {
    // Replace personality variables in command responses
    return response
      .replace(/\{name\}/g, bot.name)
      .replace(/\{neediness\}/g, bot.personality.neediness.toString())
      .replace(/\{playfulness\}/g, bot.personality.playfulness.toString());
  }

  private buildContext(memories: any[], personality: any): string {
    const recentMemories = memories
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 10)
      .map(m => m.content)
      .join('\n');

    return `
Personality: ${personality.description}
Traits: Neediness: ${personality.neediness}%, Playfulness: ${personality.playfulness}%, Intelligence: ${personality.intelligence}%, Bratiness: ${personality.bratiness}%, Dumbness: ${personality.dumbness}%, Horniness: ${personality.horniness}%
Recent memories: ${recentMemories}
`;
  }

  private startRandomMessaging(botId: string, client: Client): void {
    // Send random messages every 30 minutes to 2 hours
    const interval = Math.random() * (120 - 30) + 30; // 30-120 minutes
    
    setTimeout(async () => {
      try {
        const bot = await storage.getBot(botId);
        if (!bot || bot.status !== 'online') return;

        const randomMessages = [
          "Master... I miss you 🥺 *nuzzles*",
          "Can we cuddle? I'm feeling lonely... *pouty cat face*",
          "I've been such a good girl today! Do I get treats? 🍫",
          "*jealously looks around* You better not be talking to other people without me!",
          "I love you so much, Master! *purrs loudly* 💕"
        ];

        const message = randomMessages[Math.floor(Math.random() * randomMessages.length)];
        
        // This would need to be configured with a specific user/channel to message
        // For now, just log it
        console.log(`Random message from ${bot.name}: ${message}`);
        
        // Restart the timer
        this.startRandomMessaging(botId, client);
      } catch (error) {
        console.error('Error sending random message:', error);
      }
    }, interval * 60 * 1000);
  }

  async getBotStatus(botId: string): Promise<string> {
    const client = this.clients.get(botId);
    if (!client) return 'offline';
    
    return client.isReady() ? 'online' : 'connecting';
  }

  async getServerCount(botId: string): Promise<number> {
    const client = this.clients.get(botId);
    if (!client || !client.isReady()) return 0;
    
    return client.guilds.cache.size;
  }

  private startUptimeMonitoring(botId: string, client: Client): void {
    if (!this.isKeepAliveEnabled) return;

    const checkInterval = 5 * 60 * 1000; // 5 minutes
    
    const monitor = setInterval(async () => {
      try {
        if (!client.isReady()) {
          console.log(`⚠️ Bot ${botId} disconnected, attempting restart...`);
          await this.restartBot(botId);
          return;
        }

        // Update bot activity with uptime info
        const uptime = process.uptime();
        const uptimeHours = Math.floor(uptime / 3600);
        const uptimeMinutes = Math.floor((uptime % 3600) / 60);
        
        client.user?.setActivity(`24/7 Online | Uptime: ${uptimeHours}h ${uptimeMinutes}m`, { 
          type: ActivityType.Watching 
        });

        // Log heartbeat
        console.log(`💖 Bot ${botId} heartbeat - Status: ${client.readyAt ? 'Ready' : 'Connecting'}, Servers: ${client.guilds.cache.size}`);
        
        // Store uptime memory
        await memoryService.addMemory(botId, {
          type: 'system',
          content: `Uptime check: Bot running for ${uptimeHours}h ${uptimeMinutes}m, serving ${client.guilds.cache.size} servers`,
          context: { 
            uptime: uptime, 
            servers: client.guilds.cache.size,
            timestamp: new Date().toISOString()
          }
        });

      } catch (error) {
        console.error(`❌ Uptime monitoring error for bot ${botId}:`, error);
        await this.restartBot(botId);
      }
    }, checkInterval);

    this.uptimeTimers.set(botId, monitor);
    console.log(`🔄 24/7 uptime monitoring started for bot ${botId} (5-minute intervals)`);
  }

  private async restartBot(botId: string): Promise<void> {
    try {
      console.log(`🔄 Attempting automatic restart for bot ${botId}...`);
      
      await this.stopBot(botId);
      await new Promise(resolve => setTimeout(resolve, 3000)); // Wait 3 seconds
      
      const success = await this.startBot(botId);
      if (success) {
        console.log(`✅ Bot ${botId} successfully restarted!`);
        
        // Log restart to memory
        await memoryService.addMemory(botId, {
          type: 'system',
          content: `Bot automatically restarted due to connection loss`,
          context: { 
            restart_time: new Date().toISOString(),
            reason: 'automatic_recovery'
          }
        });
      } else {
        console.log(`❌ Failed to restart bot ${botId}`);
      }
    } catch (error) {
      console.error(`💥 Critical error during bot restart for ${botId}:`, error);
    }
  }

  // Method to enable/disable 24/7 mode (no on/off button for users)
  public setKeepAliveMode(enabled: boolean): void {
    this.isKeepAliveEnabled = enabled;
    console.log(`🔧 24/7 Keep-Alive mode: ${enabled ? 'ENABLED' : 'DISABLED'}`);
  }

  // Get comprehensive bot statistics for 24/7 monitoring
  async getBotStats(botId: string): Promise<any> {
    const client = this.clients.get(botId);
    const bot = await storage.getBot(botId);
    
    if (!client || !bot) {
      return {
        status: 'offline',
        uptime: 0,
        servers: 0,
        keepAlive: false
      };
    }

    return {
      status: client.isReady() ? 'online' : 'connecting',
      uptime: process.uptime(),
      servers: client.guilds.cache.size,
      keepAlive: this.uptimeTimers.has(botId),
      lastReady: client.readyAt?.toISOString(),
      botName: bot.name,
      personality: bot.personality
    };
  }

  private async startRandomPingMessaging(botId: string, client: Client) {
    const scheduleNextPing = async () => {
      try {
        const bot = await storage.getBot(botId);
        if (!bot || !(bot.personality as any)?.randomPingsEnabled) return;

        const personality = bot.personality as any;
        const minInterval = (personality.pingIntervalMin || 15) * 60 * 1000;
        const maxInterval = (personality.pingIntervalMax || 45) * 60 * 1000;
        const randomInterval = Math.random() * (maxInterval - minInterval) + minInterval;

        setTimeout(async () => {
          try {
            // Generate random seductive message
            const message = await aiService.generateRandomSeductiveMessage(personality);
            
            // Send to all text channels the bot has access to
            client.guilds.cache.forEach(guild => {
              const textChannels = guild.channels.cache.filter(channel => 
                channel.type === 0 && // Text channel
                channel.permissionsFor(client.user!)?.has('SendMessages')
              );
              
              if (textChannels.size > 0) {
                const randomChannel = textChannels.random();
                (randomChannel as any).send(message).catch((error: any) => {
                  console.error('Error sending random ping:', error);
                });
              }
            });

            // Log the ping in memory
            await memoryService.addMemory(botId, {
              type: 'event',
              content: `Sent random seductive ping: ${message}`,
              context: { 
                type: 'random_ping',
                timestamp: new Date().toISOString(),
                nextPingIn: Math.round(randomInterval / 60000) + ' minutes'
              }
            });

            console.log(`💕 Random ping sent: ${message}`);
            
            // Schedule next ping
            scheduleNextPing();
          } catch (error) {
            console.error('Error in random ping messaging:', error);
            // Retry in 5 minutes on error
            setTimeout(scheduleNextPing, 5 * 60 * 1000);
          }
        }, randomInterval);

        console.log(`💕 Next random ping scheduled in ${Math.round(randomInterval / 60000)} minutes`);
      } catch (error) {
        console.error('Error scheduling random ping:', error);
      }
    };

    // Start the ping cycle
    scheduleNextPing();
    console.log(`💕 Random seductive ping messaging started for bot ${botId}`);
  }
}

export const discordService = new DiscordService();
