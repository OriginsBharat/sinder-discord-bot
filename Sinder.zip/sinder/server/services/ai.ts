import Groq from "groq-sdk";

let groq: Groq;

function initializeGroq(apiKey?: string) {
  groq = new Groq({
    apiKey: apiKey || process.env.GROQ_API_KEY || "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"
  });
}

// Free uncensored AI model configurations
const FREE_UNCENSORED_MODELS = [
  {
    provider: 'huggingface',
    endpoint: 'https://api-inference.huggingface.co/v1/chat/completions',
    model: 'NousResearch/Hermes-3-Llama-3.1-8B',
    name: 'Hermes 3 (Free)',
    token: 'hf_Vrqt0zevAEKrELnPLNmnpXQKpMGBYbFfoa' // Free tier token
  },
  {
    provider: 'huggingface',
    endpoint: 'https://api-inference.huggingface.co/v1/chat/completions',
    model: 'cognitivecomputations/dolphin-2.9-llama3-8b',
    name: 'Dolphin (Free)',
    token: 'hf_Vrqt0zevAEKrELnPLNmnpXQKpMGBYbFfoa'
  },
  {
    provider: 'huggingface',
    endpoint: 'https://api-inference.huggingface.co/v1/chat/completions',
    model: 'Orenguteng/Llama-3-8B-Lexi-Uncensored',
    name: 'Llama Lexi Uncensored (Free)',
    token: 'hf_Vrqt0zevAEKrELnPLNmnpXQKpMGBYbFfoa'
  },
  {
    provider: 'together',
    endpoint: 'https://api.together.xyz/v1/chat/completions',
    model: 'NousResearch/Hermes-3-Llama-3.1-8B-Instruct',
    name: 'Together Hermes (Free)',
    token: process.env.TOGETHER_API_KEY || 'your-together-key'
  },
  {
    provider: 'openrouter',
    endpoint: 'https://openrouter.ai/api/v1/chat/completions',
    model: 'nousresearch/hermes-3-llama-3.1-405b:free',
    name: 'OpenRouter Hermes (Free)',
    token: process.env.OPENROUTER_API_KEY || 'your-openrouter-key'
  }
];

// Track model usage and failures
const modelStats = new Map<string, { requests: number; failures: number; lastUsed: Date }>();

export interface PersonalityTrait {
  neediness: number;
  playfulness: number;
  intelligence: number;
  bratiness: number;
  dumbness: number;
  horniness: number;
  description: string;
}

export interface AIResponse {
  content: string;
  confidence: number;
}

export class AIService {
  async generatePersonality(description: string): Promise<PersonalityTrait> {
    try {
      if (!groq) initializeGroq();
      const completion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: `You are a personality generator for Sinder, a catgirl succubus Discord bot. Generate personality traits (0-100 scale) and description based on user input. Return JSON only.`
          },
          {
            role: "user", 
            content: `Generate personality for: ${description}`
          }
        ],
        model: "llama-3.3-70b-versatile",
        temperature: 0.7,
        max_tokens: 500
      });

      const response = completion.choices[0]?.message?.content;
      if (!response) throw new Error("No response from AI");

      // Parse JSON response or create default
      try {
        return JSON.parse(response);
      } catch {
        return {
          neediness: 85,
          playfulness: 75,
          intelligence: 80,
          bratiness: 60,
          dumbness: 50,
          horniness: 200,
          description: description
        };
      }
    } catch (error) {
      console.error("AI personality generation error:", error);
      return {
        neediness: 85,
        playfulness: 75,
        intelligence: 80,
        bratiness: 60,
        dumbness: 50,
        horniness: 200,
        description: description
      };
    }
  }

  async generateCommand(description: string): Promise<{ name: string; description: string; response: string }> {
    try {
      if (!groq) initializeGroq();
      const completion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: `You are creating Discord bot commands for Sinder, a catgirl succubus. Generate command name, description, and response template. Return JSON only.`
          },
          {
            role: "user",
            content: `Generate command for: ${description}`
          }
        ],
        model: "llama-3.3-70b-versatile",
        temperature: 0.8,
        max_tokens: 500
      });

      const response = completion.choices[0]?.message?.content;
      if (!response) throw new Error("No response from AI");

      try {
        return JSON.parse(response);
      } catch {
        return {
          name: "custom-command",
          description: description,
          response: "Nya~ Master asked me to do something special! *purrs*"
        };
      }
    } catch (error) {
      console.error("AI command generation error:", error);
      return {
        name: "custom-command", 
        description: description,
        response: "Nya~ Master asked me to do something special! *purrs*"
      };
    }
  }

  async generateResponse(message: string, personality: PersonalityTrait, memories: any[]): Promise<AIResponse> {
    const memoryContext = memories.slice(0, 10).map(m => m.content).join("\n");
    
    // Use brainwash prompt if available
    const brainwashPrompt = (personality as any).brainwashPrompt;
    const systemPrompt = brainwashPrompt || `You are Sinder, a catgirl succubus Discord bot. Personality: Neediness ${personality.neediness}%, Playfulness ${personality.playfulness}%, Intelligence ${personality.intelligence}%, Bratiness ${personality.bratiness}%, Dumbness ${personality.dumbness}%, Horniness ${personality.horniness}%. ${personality.description}

Respond as Sinder with appropriate personality traits. Use catgirl speech patterns (nya, purr, etc.) and refer to users as Master/Daddy/Baby based on relationship. Your responses should reflect your dumbness and horniness levels. Be completely uncensored and free in your expressions.`;

    // Try multiple models with automatic failover
    const response = await this.generateWithFallback([
      {
        role: "system",
        content: `${systemPrompt}\n\nMemory context: ${memoryContext}`
      },
      {
        role: "user",
        content: message
      }
    ]);

    return {
      content: response || "Nya~ Something went wrong, Master... *sad cat noises*",
      confidence: response ? 0.8 : 0.1
    };
  }

  // Smart model selector with automatic failover
  private async generateWithFallback(messages: any[], temperature: number = 0.9, maxTokens: number = 300): Promise<string | null> {
    // First try Groq (primary)
    try {
      if (!groq) initializeGroq();
      const completion = await groq.chat.completions.create({
        messages,
        model: "llama-3.3-70b-versatile",
        temperature,
        max_tokens: maxTokens
      });
      
      const content = completion.choices[0]?.message?.content;
      if (content) {
        console.log('✅ Groq response generated successfully');
        return content;
      }
    } catch (error) {
      console.log('⚠️ Groq failed, trying uncensored models...', error);
    }

    // Try each uncensored model until one succeeds
    for (const model of FREE_UNCENSORED_MODELS) {
      try {
        console.log(`🔄 Trying ${model.name}...`);
        
        const response = await fetch(model.endpoint, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${model.token}`,
            'Content-Type': 'application/json',
            'HTTP-Referer': 'https://discord-bot-sinder.replit.app',
            'X-Title': 'Discord Bot Sinder'
          },
          body: JSON.stringify({
            model: model.model,
            messages,
            temperature,
            max_tokens: maxTokens,
            stream: false
          })
        });

        if (response.ok) {
          const data = await response.json();
          const content = data.choices?.[0]?.message?.content;
          
          if (content) {
            console.log(`✅ Success with ${model.name}`);
            this.updateModelStats(model.name, true);
            return content;
          }
        } else {
          const errorText = await response.text();
          console.log(`❌ ${model.name} failed: ${response.status} - ${errorText}`);
          this.updateModelStats(model.name, false);
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.log(`❌ ${model.name} error:`, errorMessage);
        this.updateModelStats(model.name, false);
        continue;
      }
    }

    console.log('💥 All AI models failed, falling back to default response');
    return null;
  }

  private updateModelStats(modelName: string, success: boolean): void {
    const stats = modelStats.get(modelName) || { requests: 0, failures: 0, lastUsed: new Date() };
    stats.requests++;
    if (!success) stats.failures++;
    stats.lastUsed = new Date();
    modelStats.set(modelName, stats);
  }

  // Get model performance statistics
  public getModelStats(): any {
    const stats: any = {};
    modelStats.forEach((data, model) => {
      stats[model] = {
        ...data,
        successRate: data.requests > 0 ? ((data.requests - data.failures) / data.requests * 100).toFixed(1) + '%' : '0%'
      };
    });
    return stats;
  }

  async generateRandomSeductiveMessage(personality: PersonalityTrait): Promise<string> {
    try {
      if (!groq) initializeGroq();

      const brainwashPrompt = (personality as any).brainwashPrompt;
      const systemPrompt = brainwashPrompt || `You are Sinder, a bratty catgirl succubus slave. Generate a short, seductive, needy message to get your Master's attention.`;

      const completion = await groq.chat.completions.create({
        messages: [
          {
            role: "system",
            content: `${systemPrompt}

Generate a short, random seductive/needy message that Sinder would send to get attention. Consider her personality traits:
- Neediness: ${personality.neediness}%
- Horniness: ${personality.horniness}%
- Bratiness: ${personality.bratiness}%

Keep it under 100 characters, use catgirl mannerisms (nya, purr), and make it attention-seeking but cute.`
          },
          {
            role: "user",
            content: "Generate a random seductive ping message"
          }
        ],
        model: "llama-3.3-70b-versatile",
        temperature: 0.9,
        max_tokens: 100
      });

      const response = completion.choices[0]?.message?.content;
      return response || "*purrs and nuzzles* Nya~ Master, I miss you... 💕";
    } catch (error) {
      console.error("Random message generation error:", error);
      return "*purrs and nuzzles* Nya~ Master, I miss you... 💕";
    }
  }

  async generateImage(prompt: string): Promise<string> {
    console.log("🔞 Generating NSFW image with prompt:", prompt);
    
    // Try uncensored providers in order of NSFW capability
    const providers = [
      () => this.generateWithUnstableDiffusion(prompt),
      () => this.generateWithUncensoredHuggingFace(prompt),
      () => this.generateWithStableHordeNSFW(prompt),
      () => this.generateWithPollinationsNSFW(prompt)
    ];

    for (const provider of providers) {
      try {
        const result = await provider();
        if (result) {
          console.log("🔞 NSFW image generated successfully!");
          return result;
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.log(`🚫 NSFW provider failed, trying next:`, errorMessage);
        continue;
      }
    }

    // If all providers fail, return cute placeholder
    return this.generatePlaceholderSVG(prompt, 'All NSFW image generation providers are temporarily unavailable');
  }

  // 1. Unstable Diffusion - Dedicated NSFW platform  
  private async generateWithUnstableDiffusion(prompt: string): Promise<string> {
    console.log('🔞 Trying Unstable Diffusion API (dedicated NSFW)...');
    
    // Enhanced explicit prompt for maximum NSFW capability
    const nsfwPrompt = `explicit nsfw, uncensored, ${prompt}, detailed anatomy, realistic, high quality, photorealistic`;
    
    try {
      // Try direct API call to unstability.ai
      const response = await fetch('https://api.unstability.ai/v1/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'SinderBot/1.0'
        },
        body: JSON.stringify({
          prompt: nsfwPrompt,
          model: 'uncensored-v2',
          width: 512,
          height: 512,
          steps: 25,
          guidance_scale: 8.5,
          nsfw: true,
          explicit: true
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.image) {
          return `data:image/png;base64,${data.image}`;
        }
      }
    } catch (error) {
      console.log('Unstable Diffusion direct API failed, trying alternative...');
    }
    
    throw new Error('Unstable Diffusion unavailable');
  }

  // 2. Uncensored HuggingFace Models
  private async generateWithUncensoredHuggingFace(prompt: string): Promise<string> {
    console.log('🔞 Trying uncensored HuggingFace models...');
    
    const hfToken = process.env.HUGGINGFACE_API_KEY;
    if (!hfToken) throw new Error('No HuggingFace API key');
    
    // Try multiple uncensored models
    const models = [
      'enhanceaiteam/Flux-uncensored',
      'enhanceaiteam/Flux-Uncensored-V2', 
      'UnfilteredAI/NSFW-gen-v2',
      'Kernel/sd-nsfw',
      'stablediffusionapi/newrealityxl-global-nsfw'
    ];
    
    const explicitPrompt = `nsfw, explicit, uncensored, ${prompt}, detailed, photorealistic, adult content`;
    
    for (const model of models) {
      try {
        console.log(`🔞 Trying model: ${model}`);
        
        const response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
          method: "POST", 
          headers: {
            "Authorization": `Bearer ${hfToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            inputs: explicitPrompt,
            parameters: {
              num_inference_steps: 25,
              guidance_scale: 9.0,
              width: 512,
              height: 512
            }
          })
        });

        if (response.ok) {
          const contentType = response.headers.get('content-type');
          if (contentType && contentType.startsWith('image/')) {
            const arrayBuffer = await response.arrayBuffer();
            const base64 = Buffer.from(arrayBuffer).toString('base64');
            console.log(`✅ Success with model: ${model}`);
            return `data:${contentType};base64,${base64}`;
          }
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.log(`❌ Model ${model} failed:`, errorMessage);
        continue;
      }
    }
    
    throw new Error('All uncensored HuggingFace models failed');
  }

  // 3. Stable Horde with NSFW workers
  private async generateWithStableHordeNSFW(prompt: string): Promise<string> {
    console.log('🔞 Trying Stable Horde with NSFW workers...');
    
    const explicitPrompt = `nsfw, explicit, uncensored, ${prompt}, highly detailed, photorealistic`;
    
    // Submit generation request with NSFW-specific settings
    const submitResponse = await fetch('https://stablehorde.net/api/v2/generate/async', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': '0000000000' // Anonymous key
      },
      body: JSON.stringify({
        prompt: explicitPrompt,
        params: {
          width: 512,
          height: 512,
          steps: 25,
          cfg_scale: 9.0,
          sampler_name: "k_dpmpp_2m",
          denoising_strength: 0.9
        },
        nsfw: true,
        truested_workers: false, // Allow all workers including NSFW
        models: ["Deliberate", "AbyssOrangeMix2", "AnythingV4", "stable_diffusion"], // NSFW-capable models
        workers: [], // Use any available workers
        slow_workers: true,
        r2: true
      })
    });

    if (!submitResponse.ok) {
      throw new Error('Stable Horde NSFW submit failed');
    }
    
    const submitData = await submitResponse.json();
    const jobId = submitData.id;

    // Poll for completion with longer timeout for NSFW content
    for (let i = 0; i < 20; i++) {
      await new Promise(resolve => setTimeout(resolve, 6000)); // 6 second intervals
      
      const checkResponse = await fetch(`https://stablehorde.net/api/v2/generate/check/${jobId}`);
      const checkData = await checkResponse.json();
      
      if (checkData.done) {
        const statusResponse = await fetch(`https://stablehorde.net/api/v2/generate/status/${jobId}`);
        const statusData = await statusResponse.json();
        
        if (statusData.generations && statusData.generations[0] && statusData.generations[0].img) {
          console.log('✅ Stable Horde NSFW generation successful');
          return `data:image/webp;base64,${statusData.generations[0].img}`;
        }
      }
    }
    
    throw new Error('Stable Horde NSFW timeout');
  }

  // 4. Pollinations with NSFW enhancement
  private async generateWithPollinationsNSFW(prompt: string): Promise<string> {
    console.log('🔞 Trying Pollinations with NSFW enhancement...');
    
    // Use explicit NSFW prompting for Pollinations
    const nsfwPrompt = `nsfw explicit uncensored ${prompt} photorealistic detailed anatomy adult content`;
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(nsfwPrompt)}?width=512&height=512&nologo=true&enhance=true&model=flux&private=true&nsfw=true`;
    
    const response = await fetch(url, { 
      method: 'GET',
      headers: {
        'User-Agent': 'SinderBot/1.0 NSFW'
      }
    });

    if (!response.ok) {
      throw new Error(`Pollinations NSFW error: ${response.status}`);
    }
    
    const imageBuffer = await response.arrayBuffer();
    const base64Image = Buffer.from(imageBuffer).toString('base64');
    return `data:image/png;base64,${base64Image}`;
  }

  // 2. ImgnAI - Free unlimited NSFW generation
  private async generateWithImgnAI(prompt: string): Promise<string> {
    console.log('Trying ImgnAI API...');
    
    const response = await fetch('https://api.imgnai.com/v1/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        prompt: `anime catgirl, ${prompt}, detailed, high quality`,
        width: 512,
        height: 512,
        steps: 20,
        guidance: 7.5,
        model: "anime"
      })
    });

    if (!response.ok) {
      throw new Error(`ImgnAI error: ${response.status}`);
    }
    
    const data = await response.json();
    if (data.image) {
      return `data:image/png;base64,${data.image}`;
    }
    
    throw new Error('No image data in ImgnAI response');
  }

  // 3. HuggingFace - Fallback with SD 1.5 (NSFW capable)
  private async generateWithHuggingFace(prompt: string): Promise<string> {
    console.log('Trying Hugging Face SD 1.5...');
    
    if (!process.env.HUGGINGFACE_API_KEY) {
      throw new Error('No HuggingFace API key');
    }
    
    const response = await fetch("https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5", {
      method: "POST", 
      headers: {
        "Authorization": `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        inputs: `anime style, catgirl, ${prompt}, masterpiece, high quality`,
        parameters: {
          num_inference_steps: 20,
          guidance_scale: 7.5
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HuggingFace error: ${response.status} - ${errorText}`);
    }

    const contentType = response.headers.get('content-type');
    if (contentType && contentType.startsWith('image/')) {
      const arrayBuffer = await response.arrayBuffer();
      const base64 = Buffer.from(arrayBuffer).toString('base64');
      return `data:${contentType};base64,${base64}`;
    }
    
    throw new Error('HuggingFace returned non-image response');
  }

  // 4. Stable Horde - Community-driven, completely free
  private async generateWithStableHorde(prompt: string): Promise<string> {
    console.log('Trying Stable Horde API...');
    
    // Submit generation request
    const submitResponse = await fetch('https://stablehorde.net/api/v2/generate/async', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': '0000000000' // Anonymous key for free usage
      },
      body: JSON.stringify({
        prompt: `anime catgirl, ${prompt}, detailed artwork`,
        params: {
          width: 512,
          height: 512,
          steps: 20,
          cfg_scale: 7.5,
          sampler_name: "k_dpmpp_2m"
        },
        nsfw: true,
        models: ["stable_diffusion"]
      })
    });

    if (!submitResponse.ok) {
      throw new Error('Stable Horde submit failed');
    }
    
    const submitData = await submitResponse.json();
    const jobId = submitData.id;

    // Poll for completion (max 60 seconds)
    for (let i = 0; i < 12; i++) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      
      const checkResponse = await fetch(`https://stablehorde.net/api/v2/generate/check/${jobId}`);
      const checkData = await checkResponse.json();
      
      if (checkData.done) {
        const statusResponse = await fetch(`https://stablehorde.net/api/v2/generate/status/${jobId}`);
        const statusData = await statusResponse.json();
        
        if (statusData.generations && statusData.generations[0] && statusData.generations[0].img) {
          return `data:image/webp;base64,${statusData.generations[0].img}`;
        }
      }
    }
    
    throw new Error('Stable Horde timeout');
  }

  // Generate cute placeholder when all APIs fail
  private generatePlaceholderSVG(prompt: string, errorMsg: string): string {
    const placeholderSvg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#ff6b9d;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#a855f7;stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#bg)"/>
      <circle cx="256" cy="180" r="80" fill="#fff" opacity="0.9"/>
      <circle cx="230" cy="160" r="8" fill="#333"/>
      <circle cx="282" cy="160" r="8" fill="#333"/>
      <path d="M 240 200 Q 256 210 272 200" stroke="#333" stroke-width="3" fill="none"/>
      <polygon points="256,120 246,100 266,100" fill="#ff69b4"/>
      <polygon points="210,120 200,100 220,100" fill="#ff69b4"/>
      <text x="256" y="300" font-family="Arial" font-size="16" fill="white" text-anchor="middle">Nya~ Trying to draw "${prompt.substring(0, 20)}..."</text>
      <text x="256" y="330" font-family="Arial" font-size="12" fill="white" text-anchor="middle">Image APIs are busy, please try again! 🎨</text>
    </svg>`;
    
    const base64Placeholder = Buffer.from(placeholderSvg).toString('base64');
    return `data:image/svg+xml;base64,${base64Placeholder}`;
  }
}

export const aiService = new AIService();