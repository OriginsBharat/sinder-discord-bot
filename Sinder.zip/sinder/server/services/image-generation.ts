import fetch from 'node-fetch';

export interface ImageModel {
  name: string;
  endpoint: string;
  uncensored: boolean;
  free: boolean;
  description: string;
}

export const FREE_UNCENSORED_IMAGE_MODELS: ImageModel[] = [
  {
    name: "Pollinations AI",
    endpoint: "https://image.pollinations.ai/prompt/",
    uncensored: true,
    free: true,
    description: "Completely free unlimited uncensored generation"
  },
  {
    name: "ImgnAI",
    endpoint: "https://api.imgn.ai/v1/generate",
    uncensored: true,
    free: true,
    description: "Free unlimited uncensored API"
  },
  {
    name: "Stable Horde",
    endpoint: "https://stablehorde.net/api/v2/generate/async",
    uncensored: true,
    free: true,
    description: "Community-driven free uncensored generation"
  },
  {
    name: "HuggingFace SD 1.5",
    endpoint: "runwayml/stable-diffusion-v1-5",
    uncensored: true,
    free: true,
    description: "Free tier Stable Diffusion fallback"
  }
];

export class ImageGenerationService {
  private huggingFaceToken: string;
  private currentModelIndex = 0;

  constructor() {
    this.huggingFaceToken = process.env.HUGGINGFACE_TOKEN || '';
  }

  async generateImage(prompt: string, nsfw: boolean = true): Promise<{ success: boolean; imageUrl?: string; error?: string; modelUsed?: string }> {
    // Enhance prompt for uncensored generation
    const enhancedPrompt = this.enhancePrompt(prompt, nsfw);

    // Try each model with automatic failover
    for (let attempts = 0; attempts < FREE_UNCENSORED_IMAGE_MODELS.length; attempts++) {
      const model = FREE_UNCENSORED_IMAGE_MODELS[this.currentModelIndex];
      
      try {
        console.log(`🎨 Attempting image generation with ${model.name}...`);
        
        if (model.name === "Pollinations AI") {
          // Pollinations AI - Completely free, no API key needed
          const imageUrl = `${model.endpoint}${encodeURIComponent(enhancedPrompt)}?width=512&height=512&model=flux&enhance=true&nologo=true`;
          
          const response = await fetch(imageUrl);
          if (response.ok) {
            const imageBuffer = await response.arrayBuffer();
            const bufferSize = imageBuffer.byteLength;
            
            // Check if we got actual image data (not error page)
            if (bufferSize > 1000) { // Valid images should be larger than 1KB
              // Return the direct URL instead of base64 to avoid conversion issues
              console.log(`✅ Image generated successfully with ${model.name} (${bufferSize} bytes)`);
              return {
                success: true,
                imageUrl: imageUrl, // Return direct URL
                modelUsed: model.name
              };
            } else {
              console.log(`❌ ${model.name} returned invalid image data (${bufferSize} bytes)`);
            }
          } else {
            console.log(`❌ ${model.name} HTTP error: ${response.status}`);
          }
        }
        
        else if (model.name === "ImgnAI") {
          // ImgnAI - Free API
          const response = await fetch(model.endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              prompt: enhancedPrompt,
              width: 512,
              height: 512,
              steps: 20,
              seed: Math.floor(Math.random() * 1000000)
            }),
          });

          if (response.ok) {
            const result = await response.json() as any;
            if (result.image) {
              console.log(`✅ Image generated successfully with ${model.name}`);
              return {
                success: true,
                imageUrl: result.image,
                modelUsed: model.name
              };
            }
          }
        }
        
        else if (model.name === "Stable Horde") {
          // Stable Horde - Community free API
          const response = await fetch(model.endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'apikey': '0000000000' // Anonymous API key
            },
            body: JSON.stringify({
              prompt: enhancedPrompt,
              params: {
                width: 512,
                height: 512,
                steps: 20,
                sampler_name: "k_dpmpp_2m"
              },
              nsfw: nsfw,
              censor_nsfw: false,
              models: ["stable_diffusion"]
            }),
          });

          if (response.ok) {
            const result = await response.json() as any;
            if (result.id) {
              // Poll for completion
              await new Promise(resolve => setTimeout(resolve, 10000)); // Wait 10 seconds
              
              const statusResponse = await fetch(`https://stablehorde.net/api/v2/generate/status/${result.id}`);
              const statusResult = await statusResponse.json() as any;
              
              if (statusResult.done && statusResult.generations?.length > 0) {
                console.log(`✅ Image generated successfully with ${model.name}`);
                return {
                  success: true,
                  imageUrl: statusResult.generations[0].img,
                  modelUsed: model.name
                };
              }
            }
          }
        }
        
        else if (model.name === "HuggingFace SD 1.5" && this.huggingFaceToken) {
          // HuggingFace fallback
          const response = await fetch(`https://api-inference.huggingface.co/models/${model.endpoint}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${this.huggingFaceToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              inputs: enhancedPrompt,
              parameters: {
                guidance_scale: 7.5,
                num_inference_steps: 15,
                width: 512,
                height: 512
              }
            }),
          });

          if (response.ok) {
            const imageBuffer = await response.arrayBuffer();
            if (imageBuffer.byteLength > 0) {
              const base64Image = Buffer.from(imageBuffer).toString('base64');
              const imageUrl = `data:image/png;base64,${base64Image}`;
              
              console.log(`✅ Image generated successfully with ${model.name}`);
              return {
                success: true,
                imageUrl,
                modelUsed: model.name
              };
            }
          }
        }

        console.log(`❌ Failed with ${model.name}, trying next model...`);

      } catch (error) {
        console.log(`❌ Exception with ${model.name}:`, error);
      }

      // Move to next model
      this.currentModelIndex = (this.currentModelIndex + 1) % FREE_UNCENSORED_IMAGE_MODELS.length;
    }

    return {
      success: false,
      error: "All image generation models are currently unavailable. Please try again in a few minutes."
    };
  }

  private enhancePrompt(prompt: string, nsfw: boolean): string {
    let enhanced = prompt;

    // Add quality enhancers
    enhanced += ", masterpiece, best quality, ultra detailed, highly detailed, 8k, photorealistic";

    // Add style enhancers based on content
    if (prompt.toLowerCase().includes('anime') || prompt.toLowerCase().includes('manga')) {
      enhanced += ", anime style, detailed anime art";
    }

    if (nsfw) {
      // Remove any censorship constraints
      enhanced += ", uncensored, explicit, detailed";
    }

    return enhanced;
  }

  getAvailableModels(): ImageModel[] {
    return FREE_UNCENSORED_IMAGE_MODELS;
  }

  getModelStats(): { totalModels: number; availableModels: string[]; currentModel: string } {
    return {
      totalModels: FREE_UNCENSORED_IMAGE_MODELS.length,
      availableModels: FREE_UNCENSORED_IMAGE_MODELS.map(m => m.name),
      currentModel: FREE_UNCENSORED_IMAGE_MODELS[this.currentModelIndex].name
    };
  }
}

export const imageGenerationService = new ImageGenerationService();