import { storage } from '../storage';
import { type InsertMemory } from '@shared/schema';

class MemoryService {
  async addMemory(botId: string, memory: Omit<InsertMemory, 'botId'>): Promise<void> {
    try {
      await storage.createMemory({
        ...memory,
        botId,
        importance: memory.importance || 5
      });

      // Keep only the most recent 1000 memories to prevent memory bloat
      const allMemories = await storage.getMemoriesByBot(botId);
      if (allMemories.length > 1000) {
        const sortedMemories = allMemories.sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        });
        
        // Delete oldest memories
        const toDelete = sortedMemories.slice(1000);
        for (const memory of toDelete) {
          await storage.deleteMemory(memory.id);
        }
      }
    } catch (error) {
      console.error('Error adding memory:', error);
    }
  }

  async getRecentMemories(botId: string, limit: number = 50): Promise<any[]> {
    try {
      const memories = await storage.getMemoriesByBot(botId);
      return memories
        .sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        })
        .slice(0, limit);
    } catch (error) {
      console.error('Error getting recent memories:', error);
      return [];
    }
  }

  async getMemoriesByType(botId: string, type: string): Promise<any[]> {
    try {
      const memories = await storage.getMemoriesByBot(botId);
      return memories.filter(memory => memory.type === type);
    } catch (error) {
      console.error('Error getting memories by type:', error);
      return [];
    }
  }

  async getMemoryStats(botId: string): Promise<{
    conversations: number;
    emotions: number;
    preferences: number;
    events: number;
    total: number;
  }> {
    try {
      const memories = await storage.getMemoriesByBot(botId);
      
      return {
        conversations: memories.filter(m => m.type === 'conversation').length,
        emotions: memories.filter(m => m.type === 'emotion').length,
        preferences: memories.filter(m => m.type === 'preference').length,
        events: memories.filter(m => m.type === 'event').length,
        total: memories.length
      };
    } catch (error) {
      console.error('Error getting memory stats:', error);
      return { conversations: 0, emotions: 0, preferences: 0, events: 0, total: 0 };
    }
  }

  async searchMemories(botId: string, query: string): Promise<any[]> {
    try {
      const memories = await storage.getMemoriesByBot(botId);
      const lowerQuery = query.toLowerCase();
      
      return memories.filter(memory => 
        memory.content.toLowerCase().includes(lowerQuery) ||
        JSON.stringify(memory.context).toLowerCase().includes(lowerQuery)
      );
    } catch (error) {
      console.error('Error searching memories:', error);
      return [];
    }
  }

  async updateMemoryImportance(memoryId: string, importance: number): Promise<boolean> {
    try {
      // This would require updating the storage interface to support memory updates
      // For now, we'll just log it
      console.log(`Updating memory ${memoryId} importance to ${importance}`);
      return true;
    } catch (error) {
      console.error('Error updating memory importance:', error);
      return false;
    }
  }
}

export const memoryService = new MemoryService();
