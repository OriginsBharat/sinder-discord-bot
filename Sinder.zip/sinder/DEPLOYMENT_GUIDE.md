# 🚀 Complete Discord Bot Deployment Guide - Free 24/7 Hosting

This guide will help you deploy your Discord bot for FREE 24/7 hosting using your Android phone!

## 📱 What You'll Need
- Android phone 
- Discord bot (this project)
- GitHub account
- Render account (free hosting)

---

## 🔧 Step 1: Get Your API Keys Ready

### Discord Bot Token
1. Open your phone browser
2. Go to `https://discord.com/developers/applications`
3. Log in to Discord
4. Tap "New Application" 
5. Name it "Sinder" and tap "Create"
6. Tap "Bot" on the left side
7. Tap "Reset Token" and copy the long text (starts with something like `MTQ4`)
8. Save this token somewhere safe - this is your DISCORD_BOT_TOKEN

### Groq API Key (Free AI)
1. Go to `https://console.groq.com`
2. Sign up for free account
3. Tap "API Keys" in menu
4. Tap "Create API Key"
5. Copy the key (starts with `gsk_`)
6. Save this - this is your GROQ_API_KEY

### Hugging Face API Key (Free Image Generation)
1. Go to `https://huggingface.co`
2. Sign up for free account
3. Tap your profile picture → Settings
4. Tap "Access Tokens"
5. Tap "New token" 
6. Select "Write" permission
7. Copy the token (starts with `hf_`)
8. Save this - this is your HUGGINGFACE_API_KEY

---

## 📂 Step 2: Upload to GitHub (Free Code Storage)

### Create GitHub Account
1. Go to `https://github.com`
2. Tap "Sign up"
3. Choose username and password
4. Verify your email

### Upload Your Project
1. Tap the "+" at top right
2. Tap "New repository"
3. Name it "discord-bot-sinder"
4. Make it "Public"
5. Tap "Create repository"

### Upload Files (Using GitHub Mobile)
1. Download GitHub app from Play Store
2. Open the app and login
3. Find your repository
4. Tap the "+" button
5. Select "Upload files"
6. Select ALL your project files:
   - client folder
   - server folder  
   - shared folder
   - package.json
   - All other files
7. Type "Initial upload" in commit message
8. Tap "Commit changes"

---

## 🌐 Step 3: Deploy on Render (Free 24/7 Hosting)

### Create Render Account
1. Go to `https://render.com`
2. Tap "Get Started for Free"
3. Sign up with GitHub (easiest option)

### Deploy Your Bot
1. Tap "New +" at top right
2. Tap "Web Service"
3. Tap "Connect" next to your GitHub repository
4. Fill in these settings:

**Basic Settings:**
- Name: `sinder-discord-bot`
- Region: `Oregon (US West)`
- Branch: `main`
- Root Directory: leave empty
- Runtime: `Node`

**Build & Deploy:**
- Build Command: `npm install`
- Start Command: `npm run dev`

**Environment Variables (THIS IS IMPORTANT!):**
Tap "Add Environment Variable" for each:

| Name | Value |
|------|-------|
| `DISCORD_BOT_TOKEN` | Your Discord token from Step 1 |
| `GROQ_API_KEY` | Your Groq key from Step 1 |
| `HUGGINGFACE_API_KEY` | Your Hugging Face key from Step 1 |
| `NODE_ENV` | `production` |
| `PORT` | `5000` |

5. Tap "Create Web Service"

### Wait for Deployment
- This takes 5-10 minutes
- You'll see logs showing build progress
- When it says "Your service is live", you're done!

---

## 🤖 Step 4: Invite Your Bot to Discord

### Get Bot Invite Link
1. Go back to `https://discord.com/developers/applications`
2. Select your bot application
3. Tap "OAuth2" → "URL Generator"
4. Check these boxes:
   - ✅ `bot`
   - ✅ `Send Messages`
   - ✅ `Read Message History`
   - ✅ `Use Slash Commands`
5. Copy the generated URL at bottom
6. Open this URL in browser
7. Select your Discord server
8. Tap "Authorize"

Your bot should now appear online in your Discord server!

---

## ✅ Step 5: Test Your Bot

Type these commands in Discord:
- `/help` - See all commands
- `/draw cute catgirl` - Generate AI art
- `/cuddle` - Get cute responses
- `/kiss` - More affection
- `/headpat` - Catgirl loves this!

---

## 🔄 How to Update Your Bot

When you want to change something:

1. Open GitHub app on phone
2. Navigate to your repository  
3. Find the file you want to edit
4. Tap the pencil icon (edit)
5. Make your changes
6. Scroll down and tap "Commit changes"
7. Render will automatically redeploy in 2-3 minutes!

---

## 📊 Monitoring Your Bot

### Check if Bot is Online
1. Go to your Render dashboard
2. Tap your service name
3. Look for green "Live" status
4. Check logs for any errors

### Bot Status in Discord
- Green dot = Online and working
- Yellow dot = Having issues
- Gray dot = Offline

---

## 🆓 Free Tier Limits

**Render Free Tier:**
- ✅ 750 hours per month (exactly 31 days = true 24/7!)
- ✅ 0.1 CPU, 512MB RAM
- ✅ Perfect for Discord bots
- ⚠️ Service sleeps after 15 minutes of no web traffic (but bot stays online!)

**To Keep Web Interface Awake (Optional):**
Add this to your bookmarks and visit once daily:
`https://your-service-name.onrender.com`

---

## 🛠️ Troubleshooting

### Bot Won't Start
1. Check Render logs for errors
2. Verify all environment variables are correct
3. Make sure Discord token hasn't expired

### Bot Goes Offline
1. Check Render service status  
2. Look at recent logs
3. Restart service if needed (tap "Manual Deploy")

### Commands Don't Work
1. Verify bot has permissions in Discord
2. Check if API keys are working
3. Look for error messages in logs

---

## 🔒 Security Tips

- Never share your API keys publicly
- Keep your GitHub repository private if you include keys in code
- Use environment variables instead of hardcoding keys
- Regenerate tokens if compromised

---

## 💡 Pro Tips

1. **Backup Your Keys**: Save all API keys in a notes app
2. **Monitor Usage**: Check Render dashboard weekly
3. **Update Dependencies**: Update npm packages monthly
4. **Join Communities**: Discord bot development servers for help

---

## 🎉 You're Done!

Your Discord bot is now running 24/7 for FREE! It will:
- ✅ Stay online 24/7 (until free tier expires)
- ✅ Respond to all commands
- ✅ Generate AI images  
- ✅ Remember conversations
- ✅ Auto-restart if it crashes

### Need Help?
- Check Render documentation
- Join Discord bot development servers
- Search GitHub issues for similar problems

**Your bot is now immortal and will serve your Discord server forever (or until the free tier runs out)!** 🚀