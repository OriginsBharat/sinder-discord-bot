#!/usr/bin/env python3
"""
Advanced 24/7 Keep-Alive System for Sinder Discord Bot
Features:
- Flask web server for external monitoring
- Self-ping mechanism every 5 minutes  
- Comprehensive health monitoring
- No manual on/off controls
"""

from flask import Flask, jsonify, render_template_string
from threading import Thread
import time
import requests
import os
import psutil
import json
from datetime import datetime

app = Flask(__name__)

# Bot status tracking
bot_stats = {
    "start_time": time.time(),
    "ping_count": 0,
    "last_ping": None,
    "status": "initializing",
    "errors": []
}

# Advanced status page with real-time monitoring
STATUS_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Sinder Bot - 24/7 Advanced Monitoring</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { 
            background: linear-gradient(135deg, #0d1117, #161b22); 
            color: #c9d1d9; 
            font-family: 'Segoe UI', Arial, sans-serif; 
            margin: 0; 
            padding: 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 40px; }
        .status-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .card { 
            background: rgba(255,255,255,0.05); 
            border: 1px solid rgba(255,255,255,0.1); 
            border-radius: 12px; 
            padding: 20px; 
            backdrop-filter: blur(10px);
        }
        .status-online { color: #58a6ff; }
        .status-error { color: #f85149; }
        .metric { display: flex; justify-content: space-between; margin: 10px 0; }
        .pulse { animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.7; } 100% { opacity: 1; } }
        .chart { height: 100px; background: rgba(255,255,255,0.02); border-radius: 8px; margin: 10px 0; }
        .logs { font-family: monospace; font-size: 12px; max-height: 200px; overflow-y: auto; background: #0d1117; padding: 10px; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🐱 Sinder Bot - Advanced 24/7 Monitoring</h1>
            <div class="status-online pulse" id="main-status">
                ✅ ONLINE - Continuous Operation Mode
            </div>
        </div>
        
        <div class="status-grid">
            <div class="card">
                <h3>🔥 Bot Status</h3>
                <div class="metric">Status: <span id="bot-status">Active</span></div>
                <div class="metric">Uptime: <span id="uptime">Calculating...</span></div>
                <div class="metric">Ping Count: <span id="ping-count">0</span></div>
                <div class="metric">Last Ping: <span id="last-ping">Never</span></div>
            </div>
            
            <div class="card">
                <h3>🖥️ System Resources</h3>
                <div class="metric">CPU Usage: <span id="cpu">0%</span></div>
                <div class="metric">Memory: <span id="memory">0MB</span></div>
                <div class="metric">Platform: <span id="platform">Unknown</span></div>
                <div class="metric">Python: <span id="python-version">Unknown</span></div>
            </div>
            
            <div class="card">
                <h3>🌐 Network Status</h3>
                <div class="metric">Self-Ping: <span id="self-ping">Active</span></div>
                <div class="metric">External Access: <span id="external">Available</span></div>
                <div class="metric">Health Endpoint: <span id="health">/health</span></div>
                <div class="metric">Monitoring: <span id="monitoring">5-min intervals</span></div>
            </div>
            
            <div class="card">
                <h3>📊 Performance Chart</h3>
                <div class="chart" id="performance-chart">
                    Real-time performance data would display here
                </div>
            </div>
            
            <div class="card">
                <h3>📝 System Logs</h3>
                <div class="logs" id="system-logs">
                    Loading system logs...
                </div>
            </div>
            
            <div class="card">
                <h3>⚙️ Configuration</h3>
                <div class="metric">Mode: <span>24/7 Always-On</span></div>
                <div class="metric">Auto-Restart: <span>Enabled</span></div>
                <div class="metric">Monitoring: <span>Advanced</span></div>
                <div class="metric">Manual Control: <span>Disabled</span></div>
            </div>
        </div>
    </div>
    
    <script>
        function updateStats() {
            fetch('/api/stats')
                .then(r => r.json())
                .then(data => {
                    document.getElementById('uptime').textContent = data.uptime_formatted;
                    document.getElementById('ping-count').textContent = data.ping_count;
                    document.getElementById('last-ping').textContent = data.last_ping || 'Never';
                    document.getElementById('cpu').textContent = data.cpu + '%';
                    document.getElementById('memory').textContent = Math.round(data.memory/1024/1024) + 'MB';
                    document.getElementById('platform').textContent = data.platform;
                    document.getElementById('python-version').textContent = data.python_version;
                })
                .catch(console.error);
        }
        
        setInterval(updateStats, 5000);
        updateStats();
        
        // Update current time
        setInterval(() => {
            document.getElementById('current-time').textContent = new Date().toLocaleString();
        }, 1000);
    </script>
</body>
</html>
"""

@app.route('/')
def home():
    return STATUS_PAGE

@app.route('/health')
def health():
    uptime = time.time() - bot_stats["start_time"]
    return jsonify({
        "status": "online",
        "timestamp": time.time(),
        "uptime": uptime,
        "uptime_formatted": format_uptime(uptime),
        "bot": "Sinder - Advanced 24/7 Catgirl AI",
        "ping_count": bot_stats["ping_count"],
        "last_ping": bot_stats["last_ping"],
        "mode": "continuous",
        "monitoring": "active"
    })

@app.route('/ping')
def ping():
    bot_stats["last_ping"] = datetime.now().isoformat()
    bot_stats["ping_count"] += 1
    return jsonify({
        "ping": "pong", 
        "timestamp": time.time(),
        "count": bot_stats["ping_count"],
        "status": "24/7 active"
    })

@app.route('/api/stats')
def api_stats():
    uptime = time.time() - bot_stats["start_time"]
    try:
        cpu_percent = psutil.cpu_percent()
        memory_info = psutil.virtual_memory()
        platform_info = os.uname()
    except:
        cpu_percent = 0
        memory_info = type('obj', (object,), {'used': 0})()
        platform_info = type('obj', (object,), {'sysname': 'Unknown'})()
    
    return jsonify({
        "uptime": uptime,
        "uptime_formatted": format_uptime(uptime),
        "ping_count": bot_stats["ping_count"],
        "last_ping": bot_stats["last_ping"],
        "cpu": cpu_percent,
        "memory": memory_info.used,
        "platform": getattr(platform_info, 'sysname', 'Unknown'),
        "python_version": f"{os.sys.version_info.major}.{os.sys.version_info.minor}",
        "errors": bot_stats["errors"][-10:]  # Last 10 errors
    })

def format_uptime(seconds):
    days = int(seconds // 86400)
    hours = int((seconds % 86400) // 3600)
    minutes = int((seconds % 3600) // 60)
    
    if days > 0:
        return f"{days}d {hours}h {minutes}m"
    elif hours > 0:
        return f"{hours}h {minutes}m"
    else:
        return f"{minutes}m"

def run():
    print("🚀 Starting advanced 24/7 monitoring server...")
    app.run(host='0.0.0.0', port=8080, debug=False, threaded=True)

def keep_alive():
    """Start the Flask server in a separate thread for 24/7 uptime"""
    bot_stats["status"] = "online"
    server_thread = Thread(target=run, daemon=True)
    server_thread.start()
    print("🔄 Advanced keep-alive server started - Bot will run 24/7")
    print("📊 Monitoring dashboard: http://localhost:8080")

def self_ping():
    """Enhanced self-ping mechanism with error handling and logging"""
    def ping_self():
        print("🏓 Self-ping mechanism activated - 5 minute intervals")
        while True:
            try:
                time.sleep(300)  # Ping every 5 minutes
                
                # Try multiple endpoints
                endpoints = [
                    'http://localhost:8080/ping',
                    f"http://localhost:5000/ping",
                    f"http://0.0.0.0:8080/ping"
                ]
                
                success = False
                for endpoint in endpoints:
                    try:
                        response = requests.get(endpoint, timeout=10)
                        if response.status_code == 200:
                            success = True
                            print(f"🏓 Self-ping successful to {endpoint} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                            break
                    except:
                        continue
                
                if not success:
                    error_msg = f"❌ All self-ping endpoints failed at {datetime.now().isoformat()}"
                    print(error_msg)
                    bot_stats["errors"].append(error_msg)
                    
            except Exception as e:
                error_msg = f"🚨 Self-ping critical error: {e}"
                print(error_msg)
                bot_stats["errors"].append(error_msg)
                
                # Keep the error log manageable
                if len(bot_stats["errors"]) > 100:
                    bot_stats["errors"] = bot_stats["errors"][-50:]
    
    ping_thread = Thread(target=ping_self, daemon=True)
    ping_thread.start()

# Auto-start when imported
if __name__ == "__main__":
    keep_alive()
    self_ping()
    print("🎯 24/7 Keep-Alive System initialized successfully!")
    print("🚀 Bot is now running in continuous mode with no manual controls")
    
    # Keep the main thread alive
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        print("🛑 24/7 system interrupted by user")
else:
    # When imported as module, auto-start services
    keep_alive()
    self_ping()